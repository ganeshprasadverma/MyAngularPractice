import { Component, OnInit } from '@angular/core';
import { DataRepositoryService } from '../../services/data-repository.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private _dataRepository: DataRepositoryService) {}

  ngOnInit() {
  }

  get currentUser() {
    return this._dataRepository.currentUser;
  }

  handleSignOut() {
    this._dataRepository.currentUser = null;
  }

}
