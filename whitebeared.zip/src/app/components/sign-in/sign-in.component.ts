import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataRepositoryService } from '../../services/data-repository.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent {

  credentials: any = {};

  constructor(private _router: Router, private _dataRepository: DataRepositoryService) { }

  signIn(credentials: any) {
    this._dataRepository.signIn(credentials)
      .subscribe(
        null,
        (err) => { console.error(err, 'Error'); },
        () => this._router.navigate(['/catalog'])
      );
  }

  cancel() {
    this._router.navigate(['/']);
  }

}
