import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CatalogComponent } from '../components/catalog/catalog.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    RouterModule,
    SharedModule
  ],
  exports: [ CatalogComponent ],
  declarations: [ CatalogComponent ]
})
export class CatalogModule { }
