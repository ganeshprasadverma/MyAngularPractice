import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { RegisterComponent } from '../components/register/register.component';
import { SignInComponent } from '../components/sign-in/sign-in.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    RouterModule.forChild([
      { path: 'users/register', component: RegisterComponent },
      { path: 'users/sign-in', component: SignInComponent }
    ])
  ],
  declarations: [ RegisterComponent, SignInComponent ]
})
export class UsersModule { }
