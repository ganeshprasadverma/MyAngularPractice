import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from '../components/navbar/navbar.component';
import { AccountMenuComponent } from '../components/account-menu/account-menu.component';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [ NavbarComponent, AccountMenuComponent ],
  declarations: [ NavbarComponent, AccountMenuComponent ]
})
export class CoreModule { }
