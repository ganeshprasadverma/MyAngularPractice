import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from './routes';
import { EmployeeService } from './shared/employee.service';
import { ImageService } from './shared/image.service';

import {DataTableModule, SharedModule, ButtonModule, DialogModule, InputTextModule,
  CalendarModule, DropdownModule, ConfirmDialogModule, ConfirmationService} from 'primeng/primeng';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from './navbar/navbar.component';
import { GalleryComponent } from './gallery/gallery.component';
import { ImageComponent } from './image/image.component';
import { FilterPipe } from './shared/filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    EmployeeDetailComponent,
    UploadImageComponent,
    NavbarComponent,
    GalleryComponent,
    ImageComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    DataTableModule,
    SharedModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    CalendarModule,
    DropdownModule,
    ConfirmDialogModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [EmployeeService, ImageService, ConfirmationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
