import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Employee } from '../model/employee.model';
import { Gender } from '../model/gender.model';
import { EmployeeService } from '../shared/employee.service';

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css']
})
export class EmployeeDetailComponent implements OnInit {
  @Input() employee: Employee;
  @Output() saveEmployeeEvent = new EventEmitter<Employee>();
  @Output() closeDialogEvent = new EventEmitter();

  selectedGender: Gender;
  genderList: Gender[] ;
  display: boolean;

  constructor(private employeeService: EmployeeService) { }

  ngOnInit() {
    this.genderList = [
      { code: 'M', name: 'Male'},
      { code: 'F', name: 'Female'}
    ];
    this.display = true;

    if ( this.employee.Id > 0 ) {
      const item: Gender = this.genderList.find( f => f.code === this.employee.Gender );
      this.selectedGender = item;
      console.log(this.genderList);
    } else {
      this.selectedGender = this.genderList[0];
    }
  }

  getDateOfBirth(event) {
    this.employee.DateOfBirth = event;
 }

  saveEmployeeInfo() {
    this.employee.Gender = this.selectedGender.code;

    if (this.employee.Id > 0) {
        this.employeeService.updateEmployee(this.employee.Id, this.employee).subscribe(
          data => {
            if ( data.Id > 0) {
              this.display = false;
              this.employee.Id = data.Id;
              this.saveEmployeeEvent.emit(this.employee);
            }
          }
        );
    } else {
      this.employeeService.saveEmployee(this.employee).subscribe(
        data => {
          console.log(data);
          if (data.Id > 0) {
            this.display = false;
            this.employee.Id = data.Id;
            console.log(data.Id);
            this.saveEmployeeEvent.emit(this.employee);
          }
        }
      );
    }
  }

  closeFormDialog() {
    this.display = false;
    this.closeDialogEvent.emit();
  }

}
