import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/employee.model';
import { EmployeeService } from '../shared/employee.service';
import { ConfirmationService } from 'primeng/components/common/confirmationservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employeeList: Employee[];
  employee: Employee;

  constructor(private employeeService: EmployeeService,
              private confirmationService: ConfirmationService, private _router: Router) { }

  ngOnInit() {
    this.getAllEmployees();
  }

  getAllEmployees() {
    this.employeeService.getAllEmployees().subscribe(
      data => {
          this.employeeList = data;
      }
    );
  }

  selectEmployee(employee: Employee) {
    this.employee = Object.assign({}, employee);
  }

  addNewEmployee() {
    this.employee = new Employee();
  }

  imageGallery() {
    this._router.navigate(['gallery']);
  }
  uploadImage() {
    this._router.navigate(['imageUpload']);
  }

  saveEmployee(employee: Employee) {
      const employeeFilterdList = this.employeeList.filter(c => c.Id === employee.Id);
      console.log(employeeFilterdList);
      if ( employeeFilterdList.length === 0) {
        this.employeeList.push(employee);
      } else {
        employeeFilterdList[0].Id = employee.Id;
        employeeFilterdList[0].FirstName = employee.FirstName;
        employeeFilterdList[0].LastName = employee.LastName;
        employeeFilterdList[0].Email = employee.Email;
        employeeFilterdList[0].Office = employee.Office;
        employeeFilterdList[0].Address = employee.Address;
        employeeFilterdList[0].Gender = employee.Gender;
        employeeFilterdList[0].DateOfBirth = employee.DateOfBirth;
        employeeFilterdList[0].PinCode = employee.PinCode;
        employeeFilterdList[0].PhotoCaption = employee.PhotoCaption;
        employeeFilterdList[0].PhotoUrl = employee.PhotoUrl;

      }
      this.employee = null;
  }

  deleteEmployee(employee: Employee) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to remove candidate?',
      accept: () => {
          this.employeeService.deleteEmployee(employee.Id).subscribe(
            data => {
                if (data.Id > 0) {
                    this.employeeList = this.employeeList.filter(c => c !== employee);
                }
            }
        );
      }
    });
  }

  closeDialogForm() {
    this.employee = null;
  }

}
