import { Component, OnInit, OnChanges } from '@angular/core';
import { ImageService } from '../shared/image.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit, OnChanges {
  images: any[];
  filterBy ?= 'all';
  visibleImages: any[] = [];

  constructor(private imageService: ImageService, private _router: Router) {
    console.log(this.filterBy);
    this.visibleImages = this.imageService.getImages();
  }

  ngOnChanges() {
    this.visibleImages = this.imageService.getImages();
  }

  ngOnInit() {
  }

  backToEmpList() {
    this._router.navigate(['empList']);
  }
}
