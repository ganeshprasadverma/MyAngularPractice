import { Injectable } from '@angular/core';
import { Employee } from '../model/employee.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json'})
};

@Injectable()
export class EmployeeService {

  webApiUri = 'http://localhost:1250//api/Employee';

  constructor(private _http: HttpClient) { }

  getAllEmployees() {
    return this._http.get<Employee[]>(this.webApiUri);
  }

  saveEmployee(employee: Employee) {
    const body = JSON.stringify(employee);
    return this._http.post<any>(this.webApiUri, body, httpOptions);
  }

  updateEmployee(id: number, employee: Employee) {
    const body = JSON.stringify(employee);
    return this._http.put<any>(this.webApiUri + '/' + id, body, httpOptions);
  }

  deleteEmployee(id: number) {
    return this._http.delete<any>(this.webApiUri + '/' + id);
  }

}
