import { Routes } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { GalleryComponent } from './gallery/gallery.component';
import { ImageComponent } from './image/image.component';

export const appRoutes: Routes = [
{ path: 'empList', component: EmployeeListComponent },
{ path: 'employee/{id}', component: EmployeeDetailComponent },
{ path: 'imageUpload', component: UploadImageComponent},
{ path: 'gallery', component: GalleryComponent },
  { path: 'image/:id', component: ImageComponent },
{ path: '', redirectTo: '/empList', pathMatch: 'full'}
];
