export class Gender {
    name: string;
    code: string;
  }

