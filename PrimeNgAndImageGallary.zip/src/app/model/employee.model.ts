export class Employee {
    Id: number;
    FirstName: string;
    LastName: string;
    Email: string;
    Office: string;
    Address: string;
    Gender: string;
    DateOfBirth: string;
    PinCode: number;
    PhotoCaption: string;
    PhotoUrl: string;
}
