import { Routes } from '@angular/router';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { MyTableComponent } from './my-table/my-table.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { CreateEmployeeCanDeactivateGuardService } from './shared/create-employee-can-deactivate-guard.service';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeeListResolverService } from './shared/employee-list-resolver.service';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EmployeeDetailsGuardService } from './shared/employee-details-guard.service';

export const appRoutes: Routes = [
    { path: 'dashboard', component: MyDashboardComponent },
    { path: 'table', component: MyTableComponent },
    {
        path: 'list',
        component: ListEmployeesComponent,
        resolve: { employeeList: EmployeeListResolverService }
    },
    {
        path: 'edit/:id',
        component: CreateEmployeeComponent,
        canDeactivate: [CreateEmployeeCanDeactivateGuardService]
    },
    {
        path: 'employees/:id',
        component: EmployeeDetailsComponent,
        canActivate: [EmployeeDetailsGuardService]
    },
    { path: 'notfound', component: PageNotFoundComponent },
    { path: '', redirectTo: '/dashboard', pathMatch: 'full'},
    { path: '**', component: PageNotFoundComponent }
];
