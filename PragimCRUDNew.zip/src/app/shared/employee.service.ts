import { Injectable } from '@angular/core';
import { Employee } from '../model/employee.model';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
// import 'rxjs/operator/delay';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  readonly baseUrl = 'http://localhost:3000/employees';

  constructor(private _httpService: HttpClient) { }

  private listEmployees: Employee[] = [
    {
      id: 1,
      name: 'Ganesh',
      gender: 'Male',
      contactPreferences: 'Email',
      email: 'ganesh.verma38@gmail.com',
      dateOfBirth: new Date('08/07/1990'),
      phoneNumber: 9206419928,
      department: '3',
      isActive: true,
      photoPath: 'assets/images/gpv.jpg'
    },
    {
      id: 2,
      name: 'Prasad',
      gender: 'Female',
      contactPreferences: 'Email',
      email: 'ganesh.verma38@gmail.com',
      dateOfBirth: new Date('08/07/1990'),
      phoneNumber: 8660931498,
      department: '3',
      isActive: true,
      photoPath: 'assets/images/gpv.jpg'
    },
    {
      id: 3,
      name: 'Verma',
      gender: 'Male',
      contactPreferences: 'Email',
      email: 'ganesh.verma38@gmail.com',
      dateOfBirth: new Date('08/07/1990'),
      phoneNumber: 9206419928,
      department: '2',
      isActive: true,
      photoPath: 'assets/images/gpv1.png',
    }
  ];

  // getEmployees(): Employee[] {
  //   return this.listEmployees;
  // }

  getEmployees(): Observable<Employee[]> {
    // return of(this.listEmployees);
    return this._httpService.get<Employee[]>(this.baseUrl)
                            .pipe(catchError(this.handleError));
  }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.log('Client Side Error : ' + errorResponse.error.message);
    } else {
      console.log('Server Side Error : ' + errorResponse);
    }

    return throwError('There is a problem with the service. We are notified and working. Please try again later');
  }

  deleteEmployee(id: number) {
    const index = this.listEmployees.findIndex(e => e.id === id);
    if (index !== -1) {
      this.listEmployees.splice(index, 1);
      console.log('employee deleted');
    }
  }

  addEmployee(employee: Employee): Observable<Employee> {
      return this._httpService.post<Employee>(this.baseUrl, employee, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      }).pipe( catchError(this.handleError));
  }

  updateEmployee(employee: Employee): Observable<void> {

     return this._httpService.put<void>(`${this.baseUrl}/${employee.id}`, employee, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      }).pipe(catchError(this.handleError));
  }

  getEmployee(id: number): Observable<Employee> {
    return this._httpService.get<Employee>(`${this.baseUrl}/${id}`)
                .pipe(catchError(this.handleError));
  }

  // save(employee: Employee) {
  //   if (employee.id === null) {
  //     const maxId = this.listEmployees.reduce(function(e1, e2) {
  //       return (e1.id > e2.id) ? e1 : e2;
  //     }).id;
  //     employee.id = maxId + 1;
  //     this.listEmployees.push(employee);
  //   } else {
  //     const foundIndex = this.listEmployees.findIndex(e => e.id === employee.id);
  //     this.listEmployees[foundIndex] = employee;
  //   }
  // }

  // getEmployee(id: number): Employee {
  //   return this.listEmployees.find(emp => emp.id === id);
  // }
}
