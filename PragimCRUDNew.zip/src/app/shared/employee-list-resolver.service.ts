import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Employee } from '../model/employee.model';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { EmployeeService } from './employee.service';
import { ResolvedEmployeeList } from '../model/resolved-employeelist.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeListResolverService implements Resolve<ResolvedEmployeeList> {

  constructor(private _employeeService: EmployeeService) { }

  resolve ( route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ResolvedEmployeeList> {
    return this._employeeService.getEmployees()
                        .pipe(
                          map( (employeeList) => new ResolvedEmployeeList(employeeList)),
                          catchError( (err: any) => of(new ResolvedEmployeeList(null, err)))
                        );
  }
}


// export class EmployeeListResolverService implements Resolve<Employee[]> {

//   constructor(private _employeeService: EmployeeService) { }

//   resolve ( route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Employee[]> {
//     return this._employeeService.getEmployees().pipe();
//   }
// }
