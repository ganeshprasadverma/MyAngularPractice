import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Router, ActivatedRoute } from '@angular/router';

import { Employee } from '../model/employee.model';
import { Department } from '../model/department.model';
import { EmployeeService } from '../shared/employee.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  @ViewChild('employeeForm') public createEmployeeForm: NgForm;
  previewPhoto = false;
  panelTitle: string;
  // datePickerConfig: Partial<BsDatepickerConfig>;

  employee: Employee;

  departments: Department[] = [
    { id: 1, name: 'Help Desk' },
    { id: 2, name: 'HR' },
    { id: 3, name: 'IT' },
    { id: 4, name: 'Payroll' },
  ];

  constructor(private _employeeService: EmployeeService,
    private _router: Router, private _route: ActivatedRoute) {
    // this.datePickerConfig = Object.assign({}, {
    //   containerClass: 'theme-dark-blue',
    //   dateInputFormate: 'DD/MM/YYYY'
    // });
  }

  ngOnInit() {
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
      this.getEmployee(id);
    });
  }

  private getEmployee(id: number) {
    if (id === 0) {
      this.employee = {
        id: null,
        name: null,
        gender: null,
        contactPreferences: null,
        phoneNumber: null,
        email: '',
        dateOfBirth: null,
        department: 'select',
        isActive: null,
        photoPath: null,
      };
      this.panelTitle = 'Create Employee';
      this.createEmployeeForm.reset();
    } else {
      this.panelTitle = 'Edit Employee';
      // this.employee = Object.assign({}, this._employeeService.getEmployee(id));
      this._employeeService.getEmployee(id).subscribe( (data: Employee) => {
          this.employee = data;
       }, (error: any) => {
         console.log(error);
       });
    }
  }

  saveEmployee(): void {
    if (this.employee.id === null) {
      this._employeeService.addEmployee(this.employee).subscribe(
        (data: Employee) => {
          this.createEmployeeForm.reset();
          this._router.navigate(['list']);
        }, (error: any) => {
          console.log(error);
      });
    } else {
    this._employeeService.updateEmployee(this.employee).subscribe(
      () => {
        this.createEmployeeForm.reset();
        this._router.navigate(['list']);
      }, (error: any) => {
        console.log(error);
    });
  }
}

  // saveEmployee(): void {
  //   const newEmployee = Object.assign({}, this.employee);
  //   this._employeeService.save(newEmployee);
  //   this.createEmployeeForm.reset();
  //   this._router.navigate(['list']);
  // }

  togglePhotoPreview() {
    console.log(this.previewPhoto);
    this.previewPhoto = !this.previewPhoto;
    console.log(this.previewPhoto);
    console.log(this.employee.photoPath);
  }

}
