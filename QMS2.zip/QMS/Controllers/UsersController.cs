﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using UserManagementSystem.DAL;
using UserManagementSystem.Models;

namespace UserManagementSystem.Controllers
{
    [RoutePrefix("api/Users")]
    [Authorize]
    public class UsersController : ApiController
    {
        
        public ApplicationDbContext _context { get; set; }

        public UsersController()
        {
            _context = new ApplicationDbContext();
        }

        public Boolean isAdminUser()
        {
            if (User.Identity.IsAuthenticated)
            {
                var user = User.Identity;
                ApplicationDbContext context = new ApplicationDbContext();
                var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
                var s = UserManager.GetRoles(user.GetUserId());

                if (s[0].ToString() == "Admin")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        [HttpGet]
        [Route("GetUsers")]
        public IHttpActionResult GetUsers()
        {
            var userList = _context.Users.ToList();
            List<UserViewModel> userListModel = new List<UserViewModel>();
            foreach (var item in userList)
            {
                UserViewModel objModel = new UserViewModel();
                objModel.UserID = item.Id;
                objModel.FirstName = item.FirstName;
                objModel.LastName = item.LastName;
                objModel.Email = item.Email;

                var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_context));
                var role = userManager.GetRolesAsync(item.Id).Result;
                objModel.UserRoles = role.FirstOrDefault().ToString();

                userListModel.Add(objModel);
            }
            return Ok(userListModel);
        }

        [HttpGet]
        [Route("GetUserByID/{id}")]
        public IHttpActionResult GetUserByID(string id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                UserViewModel objModel = new UserViewModel();
                objModel.UserID = user.Id;
                objModel.FirstName = user.FirstName;
                objModel.LastName = user.LastName;
                objModel.Email = user.Email;
                objModel.DateOfBirth = user.DateOfBirth;
                objModel.Address = user.Address;
                objModel.PinCode = user.PinCode;

                var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_context));
                var role = userManager.GetRolesAsync(user.Id).Result;
                objModel.UserRoles = role.FirstOrDefault().ToString();
                return Ok(objModel);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("EditUsers")]
        public IHttpActionResult EditUsers(string Id)
        {
            var user = _context.Users.Where(m => m.Id == Id).FirstOrDefault();
            UserViewModel userModel = new UserViewModel();
            userModel.UserID = user.Id;
            userModel.FirstName = user.FirstName;
            userModel.LastName = user.LastName;
            userModel.Address = user.Address;
            userModel.PinCode = user.PinCode;
            userModel.DateOfBirth = user.DateOfBirth;
            userModel.Email = user.Email;
            var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_context));
            var userRole = userManager.GetRolesAsync(user.Id).Result;
            userModel.UserRoles = userRole.FirstOrDefault();
            return Ok(userModel);
        }

        [HttpPut]
        [Route("EditUsers/{id}")]
        public IHttpActionResult EditUsers(string id, UserViewModel model)
        {
            // ViewBag.RoleList = new SelectList(_context.Roles.ToList(), "Name", "Name");
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_context));
            var user = userManager.FindById(model.UserID);
            //user.Id = Guid.NewGuid().ToString();
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;
            // user.FullName = model.FirstName + " " + model.LastName;
            user.DateOfBirth = model.DateOfBirth;
            user.Address = model.Address;
            // user.Address1 = model.Address1;
            user.PinCode = model.PinCode;
            //ApplicationUserRole role = new ApplicationUserRole();
            //role.
            //var role = UserManager.GetRolesAsync(model.UserID).Result;
            //var newRole = _context.Roles.Where(m => m.Name == model.UserRoles.ToString()).FirstOrDefault();

            var result = userManager.Update(user);

            if (result.Succeeded)
            {
                // ViewBag.Message = "User Details Updated Successfully.";
                //Save User Role to AspNetUserRoles Table
                //UserManagementDAL objDAL = new UserManagementDAL();
                //string success = objDAL.SaveUserRole(user.Id, model.UserRoles, User.Identity.ToString());
                //if (success == "1")
                //{ }
                //else
                //{
                //    return InternalServerError(new Exception("Unable to Update Role"));
                //}
                return Ok(result);
            }
            else
            {
                return InternalServerError(new Exception("Unable to Update User"));
            }            
        }

        // DELETE: api/Questions/5
        [HttpDelete]
        [Route("DeleteUser/{id}")]
        [ResponseType(typeof(Question))]
        public IHttpActionResult DeleteUser(string id)
        {
            ApplicationUser user = _context.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            _context.Users.Remove(user);
            _context.SaveChanges();

            return Ok(user);
        }
    }
}
