﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using UserManagementSystem.DAL;
using UserManagementSystem.Models;


namespace UserManagementSystem.Controllers
{
    [RoutePrefix("api/Questions")]
    //[Authorize]
    [AllowAnonymous]
    public class QuestionsController : ApiController
    {
        private ApplicationDbContext _dbContext = new ApplicationDbContext();

        // GET: api/Questions
        [HttpGet]
        [Route("GetQuestions")]
        public IQueryable<Question> GetQuestions()
        {
            return _dbContext.Questions;
        }

        // GET: api/Questions/5
        [HttpGet]
        [Route("GetQuestionById/{id}")]
        [ResponseType(typeof(Question))]
        public IHttpActionResult GetQuestionById(int id)
        {
            Question question = _dbContext.Questions.Find(id);
            if (question == null)
            {
                return NotFound();
            }

            return Ok(question);
        }

        // PUT: api/Questions/5
        [HttpPost]
        [Route("UpdateQuestion")]
        [ResponseType(typeof(void))]
        public IHttpActionResult UpdateQuestion()
        {
            string imageName = null;
            var httpRequest = HttpContext.Current.Request;

            string qnIdOld = httpRequest["QnIDOld"];
            string qnIdNew = httpRequest["QnID"];

            if (qnIdOld == qnIdNew)
            {
                int qnId = Convert.ToInt32(qnIdOld);
                var questionDB = _dbContext.Questions.Find(qnId);

                if (questionDB != null)
                {
                    //Upload Image
                    var postedFile = httpRequest.Files["Image"];

                    if (postedFile != null)
                    {
                        //Create custom filename
                        string imageNameWithoutExtension = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
                        imageName = new String(Path.GetFileName(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
                        if (imageName != questionDB.ImageName)
                        {
                            imageName = imageNameWithoutExtension + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Second + Path.GetExtension(postedFile.FileName);
                            var filePath = HttpContext.Current.Server.MapPath("~/Images/" + imageName);
                            postedFile.SaveAs(filePath);
                        }
                    }

                    // Question question = new Question();

                    try
                    {
                        // question.QnID = qnId;
                        questionDB.QnName = httpRequest["QnName"];

                        if (postedFile != null)
                        {
                            questionDB.ImageName = imageName;
                        }
                        else
                        {
                            string postedImageName = httpRequest["ImageName"];
                            if (postedImageName != null && postedImageName != "null")
                            {
                                questionDB.ImageName = postedImageName;
                            }
                        }

                        questionDB.Option1 = httpRequest["Option1"];
                        questionDB.Option2 = httpRequest["Option2"];
                        questionDB.Option3 = httpRequest["Option3"];
                        questionDB.Option4 = httpRequest["Option4"];

                        questionDB.Answer = Convert.ToInt32(httpRequest["Answer"]);
                        questionDB.SubjectID = Convert.ToInt32(httpRequest["SubjectID"]);
                        questionDB.LevelID = Convert.ToInt32(httpRequest["LevelID"]);

                        _dbContext.Entry(questionDB).State = EntityState.Modified;
                        _dbContext.SaveChanges();
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        if (!QuestionExists(qnId))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw ex;
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                else
                {
                    return NotFound();
                }
            }
            else
            {
                return StatusCode(HttpStatusCode.InternalServerError);
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Questions
        [HttpPost]
        [Route("CreateQuestion")]
        [ResponseType(typeof(Question))]
        public IHttpActionResult CreateQuestion()
        {
            string imageName = null;
            var httpRequest = HttpContext.Current.Request;

            //Upload Image
            var postedFile = httpRequest.Files["Image"];

            //Create custom filename
            if (postedFile != null)
            {
                imageName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
                imageName = imageName + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Second + Path.GetExtension(postedFile.FileName);
                var filePath = HttpContext.Current.Server.MapPath("~/Images/" + imageName);
                postedFile.SaveAs(filePath);
            }

            Question question = new Question();

            try
            {
                question.QnName = httpRequest["QnName"];
                question.ImageName = imageName;
                question.Option1 = httpRequest["Option1"];
                question.Option2 = httpRequest["Option2"];
                question.Option3 = httpRequest["Option3"];
                question.Option4 = httpRequest["Option4"];

                question.Answer = Convert.ToInt32(httpRequest["Answer"]);
                question.SubjectID = Convert.ToInt32(httpRequest["SubjectID"]);
                question.LevelID = Convert.ToInt32(httpRequest["LevelID"]);

                _dbContext.Questions.Add(question);
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Ok(question);
        }

        // DELETE: api/Questions/5
        [HttpDelete]
        [Route("DeleteQuestion/{id}")]
        [ResponseType(typeof(Question))]
        public IHttpActionResult DeleteQuestion(int id)
        {
            Question question = _dbContext.Questions.Find(id);
            if (question == null)
            {
                return NotFound();
            }

            _dbContext.Questions.Remove(question);
            _dbContext.SaveChanges();

            return Ok(question);
        }

        [HttpPost]
        [Route("UploadQuestion")]
        public IHttpActionResult UploadQuestion()
        {
            var httpRequest = HttpContext.Current.Request;

            //Upload Image
            var postedFile = httpRequest.Files["ExcelFile"];
            string excelFileName = "";
            string filePath = "";
            if (postedFile != null)
            {
                try
                {
                    // Save Excel File in a folder                
                    excelFileName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
                    excelFileName = excelFileName + "_" + DateTime.Now.ToString("_yyyy_MM_dd_HH_mm_ss") + ".xlsx";
                    filePath = HttpContext.Current.Server.MapPath("~/UploadedQuestion/" + excelFileName);
                    postedFile.SaveAs(filePath);
                    string rootFolder = "~/UploadedQuestion/";
                    FileInfo fileInfo = new FileInfo(Path.Combine(HttpContext.Current.Server.MapPath(rootFolder), excelFileName));
                    // Read excel data using EPPlus
                    using (ExcelPackage package = new ExcelPackage(fileInfo))
                    {
                        ExcelWorksheet worksheet = package.Workbook.Worksheets["Questions"];
                        int totalRows = worksheet.Dimension.Rows;
                        int totalColumns = worksheet.Dimension.Columns;

                        DataTable dtQuestions = new DataTable();
                        dtQuestions.Columns.Add("QnName", typeof(string));
                        dtQuestions.Columns.Add("ImageName", typeof(string));
                        dtQuestions.Columns.Add("Option1", typeof(string));
                        dtQuestions.Columns.Add("Option2", typeof(string));
                        dtQuestions.Columns.Add("Option3", typeof(string));
                        dtQuestions.Columns.Add("Option4", typeof(string));
                        dtQuestions.Columns.Add("Answer", typeof(int));
                        dtQuestions.Columns.Add("SubjectID", typeof(int));
                        dtQuestions.Columns.Add("LevelID", typeof(int));

                        for (int row = 2; row <= totalRows; row++)
                        {
                            DataRow dataRow = dtQuestions.NewRow();
                            dataRow["QnName"] = worksheet.Cells[row, 1].Value.ToString();
                            string imageName = Convert.ToString(worksheet.Cells[row, 2].Value);
                            if (imageName != null && imageName.Contains(".jpg") || imageName.Contains(".png"))
                            {
                                dataRow["ImageName"] = imageName;
                            }
                            else if(imageName != null)
                            {
                                dataRow["ImageName"] = imageName + ".jpg";
                            }                            

                            dataRow["Option1"] = worksheet.Cells[row, 3].Value.ToString();
                            dataRow["Option2"] = worksheet.Cells[row, 4].Value.ToString();
                            dataRow["Option3"] = worksheet.Cells[row, 5].Value;
                            dataRow["Option4"] = worksheet.Cells[row, 6].Value;
                            dataRow["Answer"] = Convert.ToInt32(worksheet.Cells[row, 7].Value);
                            dataRow["SubjectID"] = Convert.ToInt32(worksheet.Cells[row, 8].Value);
                            dataRow["LevelID"] = Convert.ToInt32(worksheet.Cells[row, 9].Value);

                            dtQuestions.Rows.Add(dataRow);
                        }

                        // Call Data Access Layer to bulk insert questions
                        UserManagementDAL dAL = new UserManagementDAL();
                        dAL.BulkUploadQuestions(dtQuestions, User.Identity.ToString());
                    }                    
                } 
                catch (Exception ex)
                {
                    return InternalServerError(ex);
                }
            }
            else
            {
                return InternalServerError(new Exception("Please select excel file to upload."));
            }

            return Ok();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool QuestionExists(int id)
        {
            return _dbContext.Questions.Count(e => e.QnID == id) > 0;
        }
    }
}
