﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Owin;
using Owin;
using Microsoft.Owin.Cors;

[assembly: OwinStartup(typeof(UserManagementSystem.Startup))]

namespace UserManagementSystem
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.UseCors(CorsOptions.AllowAll);
            //config.EnableCors(new EnableCorsAttribute("*", headers: "*", methods: "*"));
            ConfigureAuth(app);
        }
    }
}
