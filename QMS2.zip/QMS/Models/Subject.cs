﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace UserManagementSystem.Models
{
    public class Subject
    {
        [Key]
        public int SubjectID { get; set; }
        [Required]
        public string SubjectName { get; set; }
    }
}