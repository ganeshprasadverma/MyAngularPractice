﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace UserManagementSystem.DAL
{
    public class UserManagementDAL
    {
        public string SaveUserRole(string userID, string roleID, string modifiedBy)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("Sp_SaveUserRole", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", userID);
                cmd.Parameters.AddWithValue("@RoleName", roleID);
                cmd.Parameters.AddWithValue("@ModifiedBy", modifiedBy);
                con.Open();
                string result = Convert.ToString(cmd.ExecuteScalar());
                con.Close();
                return result;
            }
        }

        public string BulkUploadQuestions(DataTable dtQuestions, string modifiedBy)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("Sp_BulkUploadQuestions", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@QuestionType", dtQuestions);
                cmd.Parameters.AddWithValue("@ModifiedBy", modifiedBy);
                con.Open();
                string result = Convert.ToString(cmd.ExecuteScalar());
                con.Close();
                return result;
            }
        }
    }
}