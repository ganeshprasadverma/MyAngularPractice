﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PrimeNGDemo.Models
{
    public class Image
    {
        [Key]
        public int ImageID { get; set; }
        public string ImageCaption { get; set; }
        public string ImageName { get; set; }
    }
}