﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PrimeNGDemo.Models
{
    public class Lesson
    {
        [Key]
        public int id { get; set; }
        public string description { get; set; }
        public string duration { get; set; }
        public int seqNo { get; set; }
        public int courseId { get; set; }
    }
}