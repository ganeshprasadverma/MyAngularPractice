﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PrimeNGDemo.Models
{
    public class Course
    {
        [Key]
        public int id { get; set; }
        public string description { get; set; }
        public string iconUrl { get; set; }
        public string courseListIcon { get; set; }
        public string longDescription { get; set; }
        public string category { get; set; }
        public int lessonsCount { get; set; }
    }
}