import { Injectable } from '@angular/core';
import { Employee } from '../model/employee.model';
import { Observable, of } from 'rxjs';
// import 'rxjs/operator/delay';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }

  private listEmployees: Employee[] = [
    {
      id: 1,
      name: 'Ganesh',
      gender: 'Male',
      contactPreferences: 'Email',
      email: 'ganesh.verma38@gmail.com',
      dateOfBirth: new Date('08/07/1990'),
      department: '3',
      isActive: true,
      photoPath: 'assets/images/gpv.jpg'
    },
    {
      id: 2,
      name: 'Prasad',
      gender: 'Female',
      contactPreferences: 'Email',
      email: 'ganesh.verma38@gmail.com',
      dateOfBirth: new Date('08/07/1990'),
      department: '3',
      isActive: true,
      photoPath: 'assets/images/gpv.jpg'
    },
    {
      id: 3,
      name: 'Verma',
      gender: 'Male',
      contactPreferences: 'Email',
      email: 'ganesh.verma38@gmail.com',
      dateOfBirth: new Date('08/07/1990'),
      department: '2',
      isActive: true,
      photoPath: 'assets/images/gpv1.png',
    }
  ];

  // getEmployees(): Employee[] {
  //   return this.listEmployees;
  // }

  getEmployees(): Observable<Employee[]> {
    return of(this.listEmployees);
  }

  save(employee: Employee) {
    this.listEmployees.push(employee);
  }

  getEmployee(id: number): Employee {
    return this.listEmployees.find(emp => emp.id === id);
  }
}
