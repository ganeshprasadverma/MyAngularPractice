import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { HomeEntryComponent } from './home-entry/home-entry.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HomeRoutingModule } from './home-routing.module';

@NgModule({
  imports: [
    SharedModule,
    HomeRoutingModule
  ],
  declarations: [HomeEntryComponent, HomeComponent, AboutComponent, ContactComponent]
})
export class HomeModule { }
