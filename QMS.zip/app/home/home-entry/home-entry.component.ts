import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-entry',
  templateUrl: './home-entry.component.html',
  styleUrls: ['./home-entry.component.css']
})
export class HomeEntryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
