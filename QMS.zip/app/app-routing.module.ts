import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { HomeModule } from './home/home.module';
import { LoginModule } from './login/login.module';
import { PageNotFoundComponent } from './common/page-not-found/page-not-found.component';
import { ForbiddenComponent } from './common/forbidden/forbidden.component';
import { QuizModule } from './quiz/quiz.module';
import { AdminModule } from './admin/admin.module';
import { UserModule } from './user/user.module';
import { SelectivePreloadingStrategyService } from './services/selective-preloading-strategy.service';
import { AuthGuard } from './services/auth.guard';

const routes: Routes = [
  { path: '', loadChildren: () => HomeModule },
  { path: 'login', loadChildren: () => LoginModule, data: { preload: true } },
  { path: 'angularquiz', loadChildren: () => QuizModule, data: { preload: true } },
  { path: 'user', loadChildren: () => UserModule, canLoad: [AuthGuard] },
  { path: 'admin', loadChildren: () => AdminModule, canLoad: [AuthGuard] },
  { path: 'pageNotFound', component: PageNotFoundComponent },
  { path: 'forbidden', component: ForbiddenComponent },
  { path: '**', redirectTo: '/pageNotFound', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    enableTracing: false,
    preloadingStrategy: SelectivePreloadingStrategyService
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
