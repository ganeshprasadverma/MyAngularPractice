import { Component, OnInit } from '@angular/core';
import { SelectivePreloadingStrategyService } from '../../services/selective-preloading-strategy.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  modules: string[];
  userClaims: any;

  constructor(private preloadStrategy: SelectivePreloadingStrategyService, private loginService: LoginService) {
    this.modules = this.preloadStrategy.preloadedModules;
  }

  ngOnInit() {
    this.loginService.getUserClaims().subscribe((data: any) => {
      this.userClaims = data;
  });
  }

}
