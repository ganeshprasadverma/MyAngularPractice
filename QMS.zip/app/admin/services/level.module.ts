export class Level {
    LevelID: number;
    LevelName: string;
}
