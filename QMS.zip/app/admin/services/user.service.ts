import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { map, catchError, retry } from 'rxjs/operators';
import { throwError, Observable } from 'rxjs';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  readonly rootUrl = 'http://localhost:26947/';

  constructor(private httpService: HttpClient) {
  }

  getUsers(): Observable<User[]> {
    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + userToken
      })
    };

    return this.httpService.get<User[]>(this.rootUrl + '/api/Users/GetUsers', httpOptions)
    .pipe(map( res => res),
      retry(3),
      catchError(this.handleError)
    );
  }

  getUserByID(id: string): Observable<User> {
    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + userToken
      })
    };

    return this.httpService.get<User>(this.rootUrl + '/api/Users/GetUserByID/' + id, httpOptions)
               .pipe(catchError(this.handleError));
  }

  createUser(user: User): Observable<User> {
    return this.httpService.post<User>(this.rootUrl + '/api/Account/Register', user)
                     .pipe(catchError(this.handleError));
  }

  updateUser(id: string, user: User): Observable<User> {
    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + userToken
      })
    };

    return this.httpService.put<User>(this.rootUrl + '/api/Users/EditUsers/' + id, user, httpOptions)
                     .pipe(catchError(this.handleError));
  }

  deleteUser(id: string): Observable<User> {
    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + userToken
      })
    };

    return this.httpService.delete<User>(this.rootUrl + '/api/Users/DeleteUser/' + id, httpOptions)
                     .pipe(catchError(this.handleError));
  }

  changePassword(body: any) {

    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + userToken
      })
    };

   return this.httpService.post(this.rootUrl + 'api/Account/ChangePassword', body, httpOptions)
                    .pipe(catchError(this.handleError));
  }

  resetPassword(body: any) {
    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + userToken
      })
    };

    return this.httpService.post(this.rootUrl + 'api/Account/SetPassword', body, httpOptions)
                    .pipe(catchError(this.handleError));
  }

  logout() {
    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + userToken
      })
    };

    this.httpService.post(this.rootUrl + 'api/Account/Logout', httpOptions).pipe(catchError(this.handleError));
  }

   // ---------------- Error Handling---------------
   private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.log('Client Side Error : ' + errorResponse.error.message);
    } else {
      console.log('Server Side Error : ' + errorResponse);
    }
    return throwError('There is a problem with the service. We are notified and working. Please try again later');
  }

}
