import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Question } from '../models/question.model';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {

  // ---------------- Properties---------------
  public readonly rootUrl = 'http://localhost:26947';

  // ---------------- Helper Methods---------------
  constructor(private httpService: HttpClient) { }


  getQuestions(): Observable<Question[]> {
    return this.httpService.get<Question[]>(this.rootUrl + '/api/Questions/GetQuestions')
                     .pipe(
                      retry(3),
                      catchError(this.handleError)
                       );
  }

  getQuestionById(id: number): Observable<Question> {
    return this.httpService.get<Question>(this.rootUrl + '/api/Questions/GetQuestionById/' + id)
                    .pipe(catchError(this.handleError));
  }

  createQuestion(formData: FormData): Observable<Question> {
    return this.httpService.post<Question>(this.rootUrl + '/api/Questions/CreateQuestion', formData)
                     .pipe(catchError(this.handleError));
  }

  updateQuestion(formData: FormData): Observable<void> {
    return this.httpService.post<void>(this.rootUrl + '/api/Questions/UpdateQuestion', formData)
                     .pipe(catchError(this.handleError));
  }

  deleteQuestion(id: number): Observable<Question> {
    return this.httpService.delete<Question>(this.rootUrl + '/api/Questions/DeleteQuestion/' + id)
                     .pipe(catchError(this.handleError));
  }

  uplaodQuestion(formData: FormData) {
    return this.httpService.post(this.rootUrl + '/api/Questions/UploadQuestion', formData)
                     .pipe(catchError(this.handleError));
  }

  // ---------------- Error Handling---------------
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.log('Client Side Error : ' + errorResponse.error.message);
    } else {
      console.log('Server Side Error : ' + errorResponse);
    }
    return throwError('There is a problem with the service. We are notified and working. Please try again later');
  }

}
