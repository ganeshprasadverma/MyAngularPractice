import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Subject } from '../models/subject.model';
import { Level } from './level.module';

@Injectable({
  providedIn: 'root'
})
export class SubjectService {

  // ---------------- Properties---------------
  readonly rootUrl = 'http://localhost:26947/';

  constructor(private httpService: HttpClient) { }

  getSubjects(): Observable<Subject[]> {
    return this.httpService.get<Subject[]>(this.rootUrl + 'api/Subjects/GetSubjects')
               .pipe(catchError(this.handleError));
  }

  createSubject(subject: Subject): Observable<Subject> {
    return this.httpService.post<Subject>(this.rootUrl + 'api/Subjects/CreateSubject', subject)
               .pipe(catchError(this.handleError));
  }

  updateSubject(id: number, subject: Subject) {
    return this.httpService.put(this.rootUrl + 'api/Subjects/UpdateSubject/' + id, subject)
                .pipe(catchError(this.handleError));
  }

  getSubjectByID(id: number | string): Observable<Subject> {
    return this.httpService.get<Subject>(this.rootUrl + 'api/Subjects/GetSubjectById/' + (+id) )
               .pipe(catchError(this.handleError));
  }

  deleteSubject(id: number | string) {
    return this.httpService.delete(this.rootUrl + 'api/Subjects/DeleteSubject/' + (+id) )
               .pipe(catchError(this.handleError));
  }

  getLevels(): Observable<Level[]> {
    return this.httpService.get<Level[]>(this.rootUrl + 'api/Subjects/GetLevels')
               .pipe(catchError(this.handleError));
  }

  // ---------------- Error Handling---------------
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.log('Client Side Error : ' + errorResponse.error.message);
    } else {
      console.log('Server Side Error : ' + errorResponse);
    }
    return throwError('There is a problem with the service. We are notified and working. Please try again later');
  }
}
