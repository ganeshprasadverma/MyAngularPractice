import { Injectable } from '@angular/core';
import { Router, Resolve, RouterStateSnapshot,
         ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { Question } from '../models/question.model';
import { QuestionService } from './question.service';


@Injectable({
    providedIn: 'root'
})
export class QuestionDetailResolverService implements Resolve<Question> {

  constructor(private questionService: QuestionService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Question> {

    const id = +route.paramMap.get('id');

    return this.questionService.getQuestionById(id).pipe(
      take(1),
      map(question => {
        if (question) {
          return question;
        } else { // id not found
          this.router.navigate(['admin/managequestions']);
          return null;
        }
      })
    );
  }

}
