import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user.model';
import { HttpErrorResponse } from '@angular/common/http';
import { MatPaginator, MatTableDataSource, MatSort, MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit, AfterViewInit {

  dataSource = new MatTableDataSource<User>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public Users: User[];

  displayedColumns = ['UserID', 'FirstName', 'LastName', 'Email', 'UserName', 'RoleName', 'Actions'];

  constructor(private userService: UserService, private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers() {
    return this.userService.getUsers().subscribe((data: User[]) => {
      this.Users = data;
      this.dataSource.data = data;
    }, (error: any) => {
      console.error(error);
      alert(error);
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  deleteUser(id: string) {
    if (confirm('Are you sure you want to delete this question?')) {
      this.userService.deleteUser(id).subscribe((data: User) => {
        this.snackBar.open('User deleted successfully', 'OK', {
          duration: 3000
        });
        this.router.navigate(['/admin/manageusers']);
        // window.location.reload();
      }, (error: any) => {
        console.error(error);
        alert(error);
      });
    } else {
      return;
    }
  }

  rowClicked(row: any): void {
    console.log('Row Clicked');
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}
