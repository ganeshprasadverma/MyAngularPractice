import { Component, OnInit } from '@angular/core';
import { User } from '../../models/user.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { DialogService } from 'src/app/services/dialog.service';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  editUserForm: FormGroup;
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  userID: string = null;
  user: User;

  constructor(private userService: UserService, private formBuilder: FormBuilder, private router: Router,
          private matSnackBar: MatSnackBar, private dialogService: DialogService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.editUserForm = this.formBuilder.group({
      userID: '',
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', Validators.required],
      dateOfBirth: [''],
      address: [''],
      pinCode: [''],
    });

    this.userID = this.route.snapshot.paramMap.get('id');
    this.getUserByID();
  }

  getUserByID() {
    this.userService.getUserByID(this.userID).subscribe((data: User) => {
      this.user = data;
      this.editUserForm.get('userID').setValue(this.user.UserID);
      this.editUserForm.get('firstName').setValue(this.user.FirstName);
      this.editUserForm.get('lastName').setValue(this.user.LastName);
      this.editUserForm.get('email').setValue(this.user.Email);
      this.editUserForm.get('dateOfBirth').setValue(this.user.DateOfBirth);
      this.editUserForm.get('address').setValue(this.user.Address);
      this.editUserForm.get('pinCode').setValue(this.user.PinCode);
    });
  }

  onSubmit() {

    const user = new User();
    user.UserID = this.userID;
    user.Email = this.editUserForm.controls['email'].value;
    user.FirstName = this.editUserForm.controls['firstName'].value;
    user.LastName = this.editUserForm.controls['lastName'].value;
    user.DateOfBirth = this.editUserForm.controls['dateOfBirth'].value;
    user.Address = this.editUserForm.controls['address'].value;
    user.PinCode = this.editUserForm.controls['pinCode'].value;

  this.userService.updateUser(this.userID, user).subscribe((data: any) => {
      if (data.Succeeded) {
        this.matSnackBar.open('User updated successfully.', 'Ok', {
          duration: 2000
        });
        this.router.navigate(['admin/manageusers']);
      } else {
        this.matSnackBar.open('Unable to register User. Internal Server Error.');
      }
    }, (error: any) => {
        console.error(error);
        this.matSnackBar.open('Unable to register User. Internal Server Error.');
        // myForm.reset();
    });
  }

}
