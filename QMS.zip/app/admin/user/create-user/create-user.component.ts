import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { DialogService } from 'src/app/services/dialog.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  registerForm: FormGroup;
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';

  constructor(private userService: UserService, private formBuilder: FormBuilder, private router: Router,
              private matSnackBar: MatSnackBar, private dialogService: DialogService) {
  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      dateOfBirth: [''],
      address: [''],
      pinCode: [''],
    });
  }

  onSubmit() {

    if (this.registerForm.controls.password.value !== this.registerForm.controls.confirmPassword.value) {
      this.matSnackBar.open('Password and Confirm Password do not match.');
      return;
    }

    const user = new User();
    user.Email = this.registerForm.controls.email.value;
    user.Password = this.registerForm.controls.password.value;
    user.FirstName = this.registerForm.controls.firstName.value;
    user.LastName = this.registerForm.controls.lastName.value;
    user.DateOfBirth = this.registerForm.controls.dateOfBirth.value;
    user.Address = this.registerForm.controls.address.value;
    user.PinCode = this.registerForm.controls.pinCode.value;

    this.userService.createUser(user).subscribe((data: any) => {
      if (data.Succeeded) {
        this.matSnackBar.open('User registration successfull.');
        this.registerForm.reset();
      } else {
        this.matSnackBar.open('Unable to register User. Internal Server Error.');
      }
    }, (error: any) => {
        console.error(error);
        this.matSnackBar.open('Unable to register User. Internal Server Error.');
        // myForm.reset();
    });
  }
}
