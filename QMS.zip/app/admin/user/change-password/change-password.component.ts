import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  createForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private userSerive: UserService, private matSnackBar: MatSnackBar) { }

  ngOnInit() {
    this.createForm = this.formBuilder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  onSubmit() {

    if (this.createForm.controls.newPassword.value !== this.createForm.controls.confirmPassword.value) {
      this.matSnackBar.open('Password and Confirm Password do not match.');
      this.createForm.reset();
      return;
    }

    const body = {
      OldPassword: this.createForm.controls.oldPassword.value,
      NewPassword: this.createForm.controls.newPassword.value,
      ConfirmPassword: this.createForm.controls.confirmPassword.value
    };

    this.userSerive.changePassword(body).subscribe((data: any) => {
      this.matSnackBar.open('Password Changed Successfully');
      this.createForm.reset();
    }, (error: any) => {
      console.error(error);
      this.createForm.reset();
      this.matSnackBar.open('Unable to change password. Inernal Server Error.');
    });
  }

}
