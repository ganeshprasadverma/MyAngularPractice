import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  createForm: FormGroup;
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';

  constructor(private formBuilder: FormBuilder, private userSerive: UserService, private matSnackBar: MatSnackBar) { }

  ngOnInit() {
    this.createForm = this.formBuilder.group({
      email: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  onSubmit() {

    if (this.createForm.controls.newPassword.value !== this.createForm.controls.confirmPassword.value) {
      this.matSnackBar.open('Password and Confirm Password do not match.');
      this.createForm.reset();
      return;
    }

    const body = {
      EmailID: this.createForm.controls['email'].value,
      NewPassword: this.createForm.controls['newPassword'].value,
      ConfirmPassword: this.createForm.controls['confirmPassword'].value
    };

    this.userSerive.resetPassword(body).subscribe((data: any) => {
      this.matSnackBar.open('Password Reset Successfully');
      this.createForm.reset();
    }, (error: any) => {
      console.error(error);
      this.matSnackBar.open('Unable to reset password. Inernal Server Error.');
    });
  }

}
