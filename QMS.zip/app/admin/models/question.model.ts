export class Question {
    QnID: number;
    QnName: string;
    ImageName: string;
    Option1: string;
    Option2: string;
    Option3: string;
    Option4: string;
    Answer: string;
    SubjectID: number;
    LevelID: number;
}
