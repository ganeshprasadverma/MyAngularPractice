export class Subject {
    SubjectID: number;
    SubjectName: string;
}
