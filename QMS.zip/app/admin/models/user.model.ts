export class User {
    UserID: string;
    FirstName: string;
    LastName: string;
    Email: string;
    Password: string;
    PhoneNumber: number;
    DateOfBirth: Date;
    Address: string;
    PinCode: number;
}
