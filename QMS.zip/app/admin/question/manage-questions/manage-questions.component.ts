import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Question } from '../../models/question.model';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { QuestionService } from '../../services/question.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Level } from '../../services/level.module';
import { SubjectService } from '../../services/subject.service';

@Component({
  selector: 'app-manage-questions',
  templateUrl: './manage-questions.component.html',
  styleUrls: ['./manage-questions.component.css']
})
export class ManageQuestionsComponent implements OnInit, AfterViewInit {

  public questions: Question[];
  dataSource = new MatTableDataSource<Question>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  levels: Level[];

  displayedColumns = ['QnID', 'QnName', 'Image', 'Option1', 'Option2', 'Option3', 'Option4', 'Answer', 'Subject', 'Level', 'Actions'];

  constructor(private questionService: QuestionService, private router: Router,
              private snackBar: MatSnackBar, private subjectService: SubjectService) { }

  ngOnInit() {
    this.getQuestions();
    this.getLevels();
  }

  getQuestions() {
    this.questionService.getQuestions().subscribe((data: Question[]) => {
      this.questions = data;
      this.dataSource.data = data;
    }, (error: HttpErrorResponse) => {
      console.error(error);
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  deleteQuestion(id: number) {
    if (confirm('Are you sure you want to delete this question?')) {
      this.questionService.deleteQuestion(id).subscribe((data: Question) => {
        this.snackBar.open('Question deleted successfully', 'OK', {
          duration: 3000
        });
        this.router.navigate(['/admin/managequestions']);
        // window.location.reload();
      }, (error: any) => {
        console.error(error);
        alert(error);
      });
    } else {
      return;
    }
  }

  rowClicked(row: any): void {
    console.log('Row Clicked');
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getLevels() {
    this.subjectService.getLevels().subscribe( (data: Level[]) => {
      this.levels = data;
    }, (error: any) => {
      console.error(error);
    });
  }

}
