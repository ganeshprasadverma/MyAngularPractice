import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { Subject } from '../../models/subject.model';
import { QuestionService } from '../../services/question.service';
import { SubjectService } from '../../services/subject.service';
import { Question } from '../../models/question.model';
import { Level } from '../../services/level.module';
import { Observable } from 'rxjs';
import { DialogService } from 'src/app/services/dialog.service';

@Component({
  selector: 'app-create-question',
  templateUrl: './create-question.component.html',
  styleUrls: ['./create-question.component.css']
})
export class CreateQuestionComponent implements OnInit {

  createForm: FormGroup;
  imageUrl = '/assets/img/default-image.png';
  fileToUpload: File;
  subjects: Subject[];
  levels: Level[];
  isSaveClicked = false;

  constructor(private questionsService: QuestionService, private formBuilder: FormBuilder, private router: Router,
              private subjectService: SubjectService, private matSnackBar: MatSnackBar,
              private dialogService: DialogService) {
    this.createForm = this.formBuilder.group({
      QnName: ['', Validators.required],
      ImageName: '',
      Option1: ['', Validators.required],
      Option2: ['', Validators.required],
      Option3: '',
      Option4: '',
      Answer: '',
      SubjectID: '',
      LevelID: ''
    });
  }

  ngOnInit() {
    this.getSubjects();
    this.getLevels();
  }

  canDeactivate(): Observable<boolean> | boolean {
    // Allow synchronous navigation (`true`) if no question or the question is unchanged

    if (this.isSaveClicked) {
      return true;
    }

    if (this.createForm.pristine && !this.createForm.dirty) {
      return true;
    }

     // Otherwise ask the user with the dialog service and return its
     // observable which resolves to true or false when the user decides
    return this.dialogService.confirm('Discard Changes ?');
}

  getSubjects() {
    this.subjectService.getSubjects().subscribe( (data: Subject[]) => {
      this.subjects = data;
    }, (error: any) => {
      console.error(error);
    });
  }

  getLevels() {
    this.subjectService.getLevels().subscribe( (data: Level[]) => {
      this.levels = data;
    }, (error: any) => {
      console.error(error);
    });
  }

  OnSubmit() {
    this.isSaveClicked = true;
    const question = new Question();
    // question.QnName = this.createForm.controls['QnName'].value;
    question.QnName = this.createForm.controls.QnName.value;
    question.ImageName = this.createForm.controls.ImageName.value;
    question.Option1 = this.createForm.controls.Option1.value;
    question.Option2 = this.createForm.controls.Option2.value;
    question.Option3 = this.createForm.controls.Option3.value;
    question.Option4 = this.createForm.controls.Option4.value;
    question.Answer = this.createForm.controls.Answer.value;
    question.SubjectID = this.createForm.controls.SubjectID.value;
    question.LevelID = this.createForm.controls.LevelID.value;

    const formData = new FormData();

    if (this.fileToUpload !== null && this.fileToUpload !== undefined) {
      formData.append('Image', this.fileToUpload, this.fileToUpload.name);
    } else {
      formData.append('Image', null);
    }

    Object.keys(question).forEach(k => {
      formData.append(k, question[k]);
    });

    this.questionsService.createQuestion(formData).subscribe(() => {
      this.matSnackBar.open('Quesiton created successfully', 'OK', {
        duration: 3000
      });
      this.router.navigate(['admin/managequestions']);
    }, (error: any) => {
      alert('Unable to Create Questions');
    });
  }

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);

    // Show image preview
    const reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
    reader.readAsDataURL(this.fileToUpload);
  }

}
