import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { QuestionService } from '../../services/question.service';

@Component({
  selector: 'app-upload-question',
  templateUrl: './upload-question.component.html',
  styleUrls: ['./upload-question.component.css']
})
export class UploadQuestionComponent implements OnInit {

  uploadForm: FormGroup;
  fileToUpload: File;

  constructor(private questionsService: QuestionService, private formBuilder: FormBuilder, private router: Router,
              private matSnackBar: MatSnackBar) {
    this.uploadForm = this.formBuilder.group({
      FileName: ['', Validators.required],
    });
  }

  ngOnInit() { }

  OnSubmit() {

    const formData = new FormData();

    if (this.fileToUpload !== null && this.fileToUpload !== undefined) {
      formData.append('ExcelFile', this.fileToUpload, this.fileToUpload.name);
    } else {
      this.matSnackBar.open('Select the Excel to upload');
      return;
    }

    this.questionsService.uplaodQuestion(formData).subscribe(() => {
      this.matSnackBar.open('Question uploaded successfully', 'OK', {
        duration: 3000
      });
      this.router.navigate(['admin/managequestions']);
    }, (error: any) => {
      alert('Unable to Upload Questions. Internal Server Error');
    });
  }

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);

    const reader = new FileReader();
    reader.onload = (event: any) => {
      this.uploadForm.controls.FileName.setValue = event.target.result;
    };
    reader.readAsDataURL(this.fileToUpload);
  }

}
