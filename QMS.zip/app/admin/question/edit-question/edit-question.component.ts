import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { Question } from '../../models/question.model';
import { Subject } from '../../models/subject.model';
import { QuestionService } from '../../services/question.service';
import { SubjectService } from '../../services/subject.service';
import { Level } from '../../services/level.module';
import { DialogService } from 'src/app/services/dialog.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-edit-question',
  templateUrl: './edit-question.component.html',
  styleUrls: ['./edit-question.component.css']
})
export class EditQuestionComponent implements OnInit {

  id: number;
  question: Question;
  updateForm: FormGroup;
  fileToUpload: File;
  imageUrl = '/assets/img/default-image.png';
  ImageValue = false;
  subjects: Subject[];
  levels: Level[];
  isSaveClicked = false;

  constructor(private quesionService: QuestionService, private router: Router, private subjectService: SubjectService,
              private route: ActivatedRoute, private snackBar: MatSnackBar, private formBuilder: FormBuilder,
              private dialogService: DialogService) {
    this.initializeForm();
  }

  initializeForm() {
    this.updateForm = this.formBuilder.group({
      QnID: '',
      QnName: ['', Validators.required],
      ImageName: [''],
      Option1: ['', Validators.required],
      Option2: ['', Validators.required],
      Option3: '',
      Option4: '',
      Answer: ['', Validators.required],
      SubjectID: '',
      LevelID: ''
    });
    this.ImageValue = false;
  }

  ngOnInit() {
    this.id = +this.route.snapshot.paramMap.get('id');
    this.getQuestionById();
    this.getSubjects();
    this.getLevels();
  }

  getQuestionById() {

    this.route.data.subscribe((data: { question: Question}) => {
      this.question = data.question;
      this.updateForm.get('QnID').setValue(this.question.QnID);
      this.updateForm.get('QnName').setValue(this.question.QnName);

      this.updateForm.get('ImageName').setValue(this.question.ImageName);
      if (this.question.ImageName !== null) {
        this.ImageValue = true;
      }

      this.updateForm.get('Option1').setValue(this.question.Option1);
      this.updateForm.get('Option2').setValue(this.question.Option2);
      this.updateForm.get('Option3').setValue(this.question.Option3);
      this.updateForm.get('Option4').setValue(this.question.Option4);
      this.updateForm.get('Answer').setValue(this.question.Answer);
      this.updateForm.get('SubjectID').setValue(this.question.SubjectID);
      this.updateForm.get('LevelID').setValue(this.question.LevelID);
    });
  }

  canDeactivate(): Observable<boolean> | boolean {
      // Allow synchronous navigation (`true`) if no question or the question is unchanged
      // if (!this.question && this.updateForm.pristine) {
      //   return true;
      // }

      if (this.isSaveClicked) {
        return true;
      }

      if (this.updateForm.pristine && !this.updateForm.dirty) {
        return true;
      }

       // Otherwise ask the user with the dialog service and return its
       // observable which resolves to true or false when the user decides
      return this.dialogService.confirm('Discard Changes ?');
  }

  OnSubmit() {
    this.isSaveClicked = true;
    const formData = new FormData();
    formData.append('QnIDOld', this.id.toString());
    formData.append('QnID', this.id.toString());
    // formData.append('QnName', this.updateForm.controls['QnName'].value);
    formData.append('QnName', this.updateForm.controls.QnName.value);
    const imageName = this.updateForm.controls.ImageName.value;
    if (imageName === null && imageName === '' && this.fileToUpload !== null
        && this.fileToUpload !== undefined && this.fileToUpload.name !== undefined) {
      formData.append('Image', this.fileToUpload, this.fileToUpload.name);
    } else if (imageName !== null && this.fileToUpload !== null
      && this.fileToUpload !== undefined && this.fileToUpload.name !== undefined) {
      formData.append('Image', this.fileToUpload, this.fileToUpload.name);
    } else if (imageName !== null) {
      formData.append('ImageName', imageName);
    } else {
      formData.append('ImageName', null);
    }
    // return;

    // formData.append('Option1', this.updateForm.controls['Option1'].value);
    formData.append('Option1', this.updateForm.controls.Option1.value);
    formData.append('Option2', this.updateForm.controls.Option2.value);
    formData.append('Option3', this.updateForm.controls.Option3.value);
    formData.append('Option4', this.updateForm.controls.Option4.value);
    formData.append('Answer', this.updateForm.controls.Answer.value);
    formData.append('SubjectID', this.updateForm.controls.SubjectID.value);
    formData.append('LevelID', this.updateForm.controls.LevelID.value);

    this.quesionService.updateQuestion(formData).subscribe(() => {
      this.snackBar.open('Quesion updated successfully', 'OK', {
        duration: 3000
      });
      this.router.navigate(['admin/managequestions']);
    }, (error: any) => {
      console.error(error);
      alert(error);
    });
  }

  getSubjects() {
    this.subjectService.getSubjects().subscribe( (data: Subject[]) => {
      this.subjects = data;
    }, (error: any) => {
      console.log(error);
    });
  }

  getLevels() {
    this.subjectService.getLevels().subscribe( (data: Level[]) => {
      this.levels = data;
    }, (error: any) => {
      console.error(error);
    });
  }

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);

    // Show image preview
    const reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
    reader.readAsDataURL(this.fileToUpload);
    this.ImageValue = false;
    this.updateForm.get('ImageName').setValue(this.fileToUpload.name);
  }

}
