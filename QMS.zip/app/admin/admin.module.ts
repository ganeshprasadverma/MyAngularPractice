import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ManageQuestionsComponent } from './question/manage-questions/manage-questions.component';
import { CreateQuestionComponent } from './question/create-question/create-question.component';
import { EditQuestionComponent } from './question/edit-question/edit-question.component';
import { ManageSubjectsComponent } from './subject/manage-subjects/manage-subjects.component';
import { EditSubjectComponent } from './subject/edit-subject/edit-subject.component';
import { ManageUsersComponent } from './user/manage-users/manage-users.component';
import { QuestionService } from './services/question.service';
import { AdminLayoutComponent } from './admin-layout/admin-layout.component';
import { SharedModule } from '../shared/shared.module';
import { EditUserComponent } from './user/edit-user/edit-user.component';
import { CreateUserComponent } from './user/create-user/create-user.component';
import { ChangePasswordComponent } from './user/change-password/change-password.component';
import { ResetPasswordComponent } from './user/reset-password/reset-password.component';
import { UploadQuestionComponent } from './question/upload-question/upload-question.component';
import { CreateSubjectComponent } from './subject/create-subject/create-subject.component';

@NgModule({
  imports: [
    SharedModule,
    AdminRoutingModule
  ],
  declarations: [
    AdminLayoutComponent,
    AdminHomeComponent,
    AdminDashboardComponent,
    ManageQuestionsComponent,
    CreateQuestionComponent,
    EditQuestionComponent,
    ManageSubjectsComponent,
    EditSubjectComponent,
    ManageUsersComponent,
    AdminLayoutComponent,
    EditUserComponent,
    CreateUserComponent,
    ChangePasswordComponent,
    ResetPasswordComponent,
    UploadQuestionComponent,
    CreateSubjectComponent
  ],
  providers: [ QuestionService ]
})
export class AdminModule { }
