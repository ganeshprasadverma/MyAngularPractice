import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ManageQuestionsComponent } from './question/manage-questions/manage-questions.component';
import { CreateQuestionComponent } from './question/create-question/create-question.component';
import { EditQuestionComponent } from './question/edit-question/edit-question.component';
import { ManageSubjectsComponent } from './subject/manage-subjects/manage-subjects.component';
import { EditSubjectComponent } from './subject/edit-subject/edit-subject.component';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { AuthGuard } from '../services/auth.guard';
import { QuestionDetailResolverService } from './services/question-detail-resolver.service';
import { ManageUsersComponent } from './user/manage-users/manage-users.component';
import { EditUserComponent } from './user/edit-user/edit-user.component';
import { CreateUserComponent } from './user/create-user/create-user.component';
import { ChangePasswordComponent } from './user/change-password/change-password.component';
import { ResetPasswordComponent } from './user/reset-password/reset-password.component';
import { UploadQuestionComponent } from './question/upload-question/upload-question.component';
import { CreateSubjectComponent } from './subject/create-subject/create-subject.component';

const adminRoutes: Routes = [
  { path: '', component: AdminHomeComponent, canActivate: [AuthGuard], data: { roles: ['Admin'] },
    children: [
      {
        path: '', canActivateChild: [AuthGuard],
        children: [
          { path: '', component: AdminDashboardComponent },
          { path: 'managequestions', component: ManageQuestionsComponent },
          { path: 'createquestion', component: CreateQuestionComponent, canDeactivate: [CanDeactivateGuard] },
          { path: 'editquestion/:id', component: EditQuestionComponent, canDeactivate: [CanDeactivateGuard],
              resolve: { question: QuestionDetailResolverService }},
          { path: 'uploadquestions', component: UploadQuestionComponent },
          { path: 'managesubjects', component: ManageSubjectsComponent },
          { path: 'editsubject/:id', component: EditSubjectComponent },
          { path: 'createsubject', component: CreateSubjectComponent },
          { path: 'manageusers', component: ManageUsersComponent },
          { path: 'editusers/:id', component: EditUserComponent },
          { path: 'createusers', component: CreateUserComponent },
          { path: 'changepassword', component: ChangePasswordComponent },
          { path: 'resetpassword', component: ResetPasswordComponent }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(adminRoutes)
  ],
  exports: [ RouterModule ]
})
export class AdminRoutingModule { }
