import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SubjectService } from '../../services/subject.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { Subject } from '../../models/subject.model';


@Component({
  selector: 'app-create-subject',
  templateUrl: './create-subject.component.html',
  styleUrls: ['./create-subject.component.css']
})
export class CreateSubjectComponent implements OnInit {

  subjectForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private subjectService: SubjectService,
              private snackBar: MatSnackBar, private router: Router) {
              }

  ngOnInit() {
    this.subjectForm = this.formBuilder.group({
      SubjectName: ['', Validators.required]
    });
  }

  OnSubmit() {
    const subject = new Subject();
    subject.SubjectName = this.subjectForm.controls.SubjectName.value;

    this.subjectService.createSubject(subject).subscribe(() => {
      this.snackBar.open('Subject created successfully', 'OK', {
        duration: 3000
      });
      this.router.navigate(['admin/managesubjects']);
    }, (error: any) => {
      console.error(error);
    });
  }

}
