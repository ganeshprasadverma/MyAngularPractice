import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SubjectService } from '../../services/subject.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { Subject } from '../../models/subject.model';

@Component({
  selector: 'app-edit-subject',
  templateUrl: './edit-subject.component.html',
  styleUrls: ['./edit-subject.component.css']
})
export class EditSubjectComponent implements OnInit {

  subjectForm: FormGroup;
  subjectID: number;

  constructor(private subjectService: SubjectService, private formBuilder: FormBuilder,
              private route: ActivatedRoute, private snackBar: MatSnackBar, private router: Router) {
    this.initializeForm();
  }

  ngOnInit() {
    this.subjectID = +this.route.snapshot.paramMap.get('id');
    this.getSubjectByID(this.subjectID);
  }

  initializeForm() {
    this.subjectForm = this.formBuilder.group({
      SubjectID: [''],
      SubjectName: ['', Validators.required]
    });
  }

  getSubjectByID(id: number) {
    this.subjectService.getSubjectByID(id).subscribe((data: Subject) => {
      this.subjectForm.get('SubjectID').setValue(data.SubjectID);
      this.subjectForm.get('SubjectName').setValue(data.SubjectName);
    });
  }

  OnSubmit() {
    const subject = new Subject();
    subject.SubjectID = this.subjectForm.controls.SubjectID.value;
    subject.SubjectName = this.subjectForm.controls.SubjectName.value;
    this.subjectService.updateSubject(this.subjectID, subject).subscribe(() => {
      this.snackBar.open('Subject Updated Successfully.', 'OK', {
        duration: 3000
      });
      this.router.navigate(['admin/managesubjects']);
    }, (error: any) => {
      console.error(error);
    });
  }

}
