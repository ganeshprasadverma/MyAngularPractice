import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Subject } from '../../models/subject.model';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { SubjectService } from '../../services/subject.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-manage-subjects',
  templateUrl: './manage-subjects.component.html',
  styleUrls: ['./manage-subjects.component.css']
})
export class ManageSubjectsComponent implements OnInit, AfterViewInit {

  public subjects: Subject[];
  dataSource = new MatTableDataSource<Subject>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  displayedColumns = ['SubjectID', 'SubjectName', 'Actions'];

  constructor(private subjectService: SubjectService, private router: Router,
              private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.getSubjects();
  }

  getSubjects() {
    this.subjectService.getSubjects().subscribe((data: Subject[]) => {
      this.subjects = data;
      this.dataSource.data = data;
    }, (error: HttpErrorResponse) => {
      console.error(error);
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(),
    filterValue = filterValue.toLowerCase(),
    this.dataSource.filter = filterValue;
  }

  deleteSubject(id: number | string) {
    this.subjectService.deleteSubject(id).subscribe(() => {
      this.snackBar.open('Subject Deleted Successfully', 'OK', {
        duration: 3000
      });
      this.router.navigate(['/admin/managesubjects']);
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  rowClicked(row: any) {
    console.log('Row Clicked');
  }
}
