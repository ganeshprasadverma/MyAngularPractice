import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuizHomeComponent } from './quiz-home/quiz-home.component';
import { AngularQuizComponent } from './angular-quiz/angular-quiz.component';
import { QuizComponent } from './quiz/quiz.component';
import { ResultComponent } from './result/result.component';

const quizRoutes: Routes = [
  {
    path: '', component: QuizHomeComponent,
    children: [
      { path: '', component: AngularQuizComponent },
      { path: 'quiz', component: QuizComponent },
      { path: 'quizresult', component: ResultComponent }
    ]
}];

@NgModule({
  imports: [
    RouterModule.forChild(quizRoutes)
  ],
  exports: [ RouterModule ]
})
export class QuizRoutingModule { }
