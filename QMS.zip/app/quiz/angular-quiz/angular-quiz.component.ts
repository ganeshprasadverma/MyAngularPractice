import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-angular-quiz',
  templateUrl: './angular-quiz.component.html',
  styleUrls: ['./angular-quiz.component.css']
})
export class AngularQuizComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit() {
  }

  StartAngularTest(subjectId: number, levelId: number) {
    localStorage.setItem('subjectId', subjectId.toString());
    localStorage.setItem('levelId', subjectId.toString());
    localStorage.setItem('qnProgress', '0');
    localStorage.setItem('qns', '');
    localStorage.setItem('seconds', '');
    this._router.navigate(['/angularquiz/quiz']);
  }

}
