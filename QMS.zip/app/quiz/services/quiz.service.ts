import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class QuizService {

  // var headers = new Headers();
  // headers.append('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
  // headers.append('Authorization', 'Bearer '+ token);
  // headers.append('Accept', 'application/json');

  // return this.http.get('http://localhost:8082/users', {headers:headers});

// ---------------- Properties---------------
readonly rootUrl = 'http://localhost:26947';
qns: any[];
seconds: number;
timer;
qnProgress: number;
correctAnswerCount = 0;

// ---------------- Helper Methods---------------
  constructor(private _httpService: HttpClient) { }

  displayTimeElapsed() {
    return Math.floor(this.seconds / 3600) + ':' + Math.floor(this.seconds / 60) + ':' + Math.floor(this.seconds % 60);
  }

  // ---------------- Http Methods---------------

  getQuestions() {
    return this._httpService.get(this.rootUrl + '/api/Quiz/Questions');
  }

  getAnswers() {
    const body = this.qns.map(x => x.QnID);
    return this._httpService.post(this.rootUrl + '/api/Quiz/Answers', body);
  }

  submitScore() {
    const body = JSON.parse(localStorage.getItem('participant'));
    body.Score = this.correctAnswerCount;
    body.TimeSpent = this.seconds;
    return this._httpService.post(this.rootUrl + '/api/Participant/UpdateOutput', body);
  }

  getSubjectList() {
    return this._httpService.get(this.rootUrl + '/api/Quiz/Subjects');
  }

  getQuestionsBySubjectId(subjectId: number, levelId: number) {
    // const reqHeader = new HttpHeaders({'No-Auth': 'True', 'Access-Control-Allow-Origin:': '*'});
    const reqHeader = new HttpHeaders({'No-Auth': 'True'});
    // return this._httpService.get(this.rootUrl + '/api/Quiz/QuestionsBySubjectId/' + subjectId, { headers: reqHeader });
    return this._httpService.get(this.rootUrl + '/api/Quiz/QuestionsBySubjectId?Id=' + subjectId + '&levelId=' + levelId);
  }
}
