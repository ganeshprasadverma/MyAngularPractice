import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuizService } from '../services/quiz.service';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  constructor(private _quizService: QuizService, private _router: Router) {}

  ngOnInit() {

    if (+localStorage.getItem('qnProgress') === 10) {

      this._quizService.seconds = +localStorage.getItem('seconds');
      this._quizService.qnProgress = +localStorage.getItem('qnProgress');
      this._quizService.qns = JSON.parse(localStorage.getItem('qns'));

      this._quizService.getAnswers().subscribe(
        (data: any) => {
          this._quizService.correctAnswerCount = 0;
          this._quizService.qns.forEach((e, i) => {
            if (e.answer === data[i]) {
              this._quizService.correctAnswerCount++;
            }
            e.correct = data[i];
          });
        }
      );
    } else {
      this._router.navigate(['/angularquiz/quiz']);
    }
  }

  restart() {
    localStorage.setItem('qnProgress', '0');
    localStorage.setItem('qns', '');
    localStorage.setItem('seconds', '');
    this._router.navigate(['/angularquiz/quiz']);
  }

}
