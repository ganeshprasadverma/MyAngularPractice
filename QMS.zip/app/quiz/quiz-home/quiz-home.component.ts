import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-home',
  templateUrl: './quiz-home.component.html',
  styleUrls: ['./quiz-home.component.css']
})
export class QuizHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
