import { NgModule } from '@angular/core';
import { QuizHomeComponent } from './quiz-home/quiz-home.component';
import { QuizRoutingModule } from './quiz-routing.module';
import { QuizComponent } from './quiz/quiz.component';
import { AngularQuizComponent } from './angular-quiz/angular-quiz.component';
import { ResultComponent } from './result/result.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  imports: [
    SharedModule,
    QuizRoutingModule
  ],
  declarations: [
    QuizHomeComponent,
    AngularQuizComponent,
    QuizComponent,
    ResultComponent
  ]
})
export class QuizModule { }
