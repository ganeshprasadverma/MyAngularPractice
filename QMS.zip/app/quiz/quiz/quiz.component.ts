import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuizService } from '../services/quiz.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  constructor(private router: Router, private quizService: QuizService) { }

  ngOnInit() {

    if (+localStorage.getItem('seconds') > 0) {
      this.quizService.seconds = +localStorage.getItem('seconds');
      this.quizService.qnProgress = +localStorage.getItem('qnProgress');
      this.quizService.qns = JSON.parse(localStorage.getItem('qns'));

      if (this.quizService.qnProgress === 10) {
        this.router.navigate(['/angularquiz/quizresult']);
      } else {
        this.startTimer();
      }
    } else {
      this.quizService.seconds = 0;
      this.quizService.qnProgress = 0;

      const subjectId = +localStorage.getItem('subjectId');
      const levelId = +localStorage.getItem('levelId');
      this.quizService.getQuestionsBySubjectId(subjectId, levelId).subscribe(
    (data: any) => {
      this.quizService.qns = data;
      if (this.quizService.qns.length > 0) {
        this.startTimer();
      }
    });

    }
  }

  startTimer() {
    this.quizService.timer = setInterval(() => {
      this.quizService.seconds++;
      localStorage.setItem('seconds', this.quizService.seconds.toString());
    }, 1000);
  }

  Answer(qID, choice) {
    this.quizService.qns[this.quizService.qnProgress].answer = choice;
    localStorage.setItem('qns', JSON.stringify(this.quizService.qns));
    this.quizService.qnProgress++;
    localStorage.setItem('qnProgress', this.quizService.qnProgress.toString());

    if (this.quizService.qnProgress === 10) {
      clearInterval(this.quizService.timer);
      this.router.navigate(['/angularquiz/quizresult']);
    }
  }


}
