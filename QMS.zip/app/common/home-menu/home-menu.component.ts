import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home-menu',
  templateUrl: './home-menu.component.html',
  styleUrls: ['./home-menu.component.css']
})
export class HomeMenuComponent implements OnInit {

  isLoggedIn$: Observable<boolean>;
  userName$: string;

  constructor(private router: Router, private loginService: LoginService) { }

  ngOnInit() {
    this.isLoggedIn$ = this.loginService.isLoggedIn;
    this.loginService.UserName.subscribe((userName: string) => {
      this.userName$ = userName;
    });
  }

  onLogout() {
    this.loginService.logout().subscribe(() => {
      this.loginService.loggedIn.next(false);
      this.loginService.UserName.next(null);
    }, (error: any) => {
      console.error(error);
      alert(error);
    });
    this.isLoggedIn$ = this.loginService.isLoggedIn;
      // localStorage.clear();
    localStorage.removeItem('userToken');
    localStorage.removeItem('username');
    this.router.navigate(['/']);
  }

}
