import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivateChild, CanLoad, Route } from '@angular/router';
import { LoginService } from './login.service';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild, CanLoad {

  isLoggedIn = false;

  constructor(private router: Router, private loginService: LoginService) {
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot):  boolean {

    this.loginService.isLoggedIn.subscribe((data: boolean) => {
      this.isLoggedIn = data;
    });

    if (this.isLoggedIn) {
      if (localStorage.getItem('userToken') !== null) {
        const roles = next.data['roles'] as Array<string>;
        if (roles) {
          const match = this.loginService.roleMatch(roles);
          if (match) {
            const url: string = state.url;
            return this.checkLogin(url);
          } else {
            this.router.navigate(['/forbidden']);
            return false;
          }
        } else {
            return true;
        }
      }
    }

      this.router.navigate(['/login']);
      return false;
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.canActivate(route, state);
  }

  canLoad(route: Route): boolean {
    const url = `/${route.path}`;
    return this.checkLogin(url);
  }

  checkLogin(url: string): boolean {

    this.loginService.isLoggedIn.subscribe((data: boolean) => {
      this.isLoggedIn = data;
    });

    if (this.isLoggedIn) {
      return true;
    }

    // Store the attempted URL for redirecting
    this.loginService.redirectUrl = url;

    // Navigate to the login page with extras
    this.router.navigate(['/login']);
    return false;
  }

}
