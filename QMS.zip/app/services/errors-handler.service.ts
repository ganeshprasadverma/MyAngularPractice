import { Injectable, ErrorHandler } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ErrorsHandler implements ErrorHandler {
  handleError(error: Error | HttpErrorResponse) {
   if (error instanceof HttpErrorResponse) {
      // Server or connection error happened
      if (!navigator.onLine) {
        // Handle offline error
        console.log('Client Side Error : ' + error.error.message);
      } else {
        // Handle Http Error (error.status === 403, 404...)
        console.log('Server Side Error : ' + error);
      }
   } else {
     // Handle Client Error (Angular Error, ReferenceError...)
   }
  // Log the error anyway
  // console.error('It happens: ', error);
  return throwError('There is a problem with the service. We are notified and working. Please try again later');
}
}
