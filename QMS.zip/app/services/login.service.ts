import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { throwError, BehaviorSubject } from 'rxjs';
import { User } from '../admin/models/user.model';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  readonly rootUrl = 'http://localhost:26947/';
  public loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  public UserName: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  // store the URL so we can redirect after logging in
  redirectUrl: string;

  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  get getUserName() {
    return this.UserName.asObservable();
  }

  constructor(private httpService: HttpClient) {
  }

  registerUser(user: User) {
    const body = {
      Email: user.Email,
      Password: user.Password,
      FirstName: user.FirstName,
      LastName: user.LastName
    };
    const reqHeader = new HttpHeaders({'No-Auth': 'True'});
    return this.httpService.post(this.rootUrl + '/api/Account/Register', body, {headers : reqHeader})
               .pipe(catchError(this.handleError));
  }

  userAuthentication(userName, password) {
    const data = 'username=' + userName + '&password=' + password + '&grant_type=password';
    // const reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-urlencoded', 'No-Auth': 'True' });
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-urlencoded',
        'No-Auth': 'True'
      })
    };
    return this.httpService.post(this.rootUrl + '/token', data, httpOptions).pipe(catchError(this.handleError));
    // return this._httpService.post(this.rootUrl + '/token', data, { headers: reqHeader });
               // .pipe(catchError(this.handleError));
  }

  getUserClaims() {

    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        Authorization: 'Bearer ' + userToken
      })
    };

    return  this.httpService.get(this.rootUrl + '/api/Account/GetUserClaims', httpOptions)
                .pipe(catchError(this.handleError));
  }

  roleMatch(allowedRoles): boolean {
    let isMatch = false;
    const userRoles: string[] = JSON.parse(localStorage.getItem('userRoles'));
    allowedRoles.forEach(element => {
      if (userRoles.indexOf(element) > -1) {
        isMatch = true;
        return false;
      }
    });
    return isMatch;
  }

  logout() {
    const userToken = localStorage.getItem('userToken');
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + userToken
      })
    };

    // const reqHeader = new HttpHeaders({'Authorization': 'Bearer ' + userToken });

    // return this._httpService.post(this.rootUrl + '/api/Account/Logout', { headers : reqHeader }).pipe(catchError(this.handleError));
    // alert(userToken);
    return this.httpService.post(this.rootUrl + '/api/Account/Logout', httpOptions)
               .pipe(catchError(this.handleError));
  }

  // ---------------- Error Handling---------------
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.log('Client Side Error : ' + errorResponse.error.message);
    } else {
      console.log('Server Side Error : ' + errorResponse);
    }
    return throwError('There is a problem with the service. We are notified and working. Please try again later');
  }
}
