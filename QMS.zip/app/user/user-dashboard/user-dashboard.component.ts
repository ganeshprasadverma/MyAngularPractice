import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

  userClaims: any;

  constructor(private loginService: LoginService) { }

  ngOnInit() {
      this.loginService.getUserClaims().subscribe((data: any) => {
        this.userClaims = data;
    });
  }

}
