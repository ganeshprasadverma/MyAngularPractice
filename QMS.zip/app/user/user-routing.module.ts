import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserEntryComponent } from './user-entry/user-entry.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { AuthGuard } from '../services/auth.guard';

const userRoutes: Routes = [
  { path: '', component: UserEntryComponent, canActivate: [AuthGuard], data: { roles: ['User'] },
    children: [
      { path: '', canActivateChild: [AuthGuard],
      children: [
        { path: '', component: UserDashboardComponent }
      ]}
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(userRoutes)
  ],
  exports: [ RouterModule ]
})
export class UserRoutingModule { }
