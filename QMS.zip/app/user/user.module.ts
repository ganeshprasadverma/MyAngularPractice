import { NgModule } from '@angular/core';
import { UserEntryComponent } from './user-entry/user-entry.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { UserRoutingModule } from './user-routing.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    SharedModule,
    UserRoutingModule
  ],
  declarations: [UserEntryComponent, UserDashboardComponent]
})
export class UserModule { }
