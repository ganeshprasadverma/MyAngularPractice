import { Component, OnInit } from '@angular/core';
import { NgForm, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { HttpErrorResponse } from '@angular/common/http';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  invalidLogin = false;
  message = '';

  constructor(private formBuilder: FormBuilder, private router: Router,
    private loginService: LoginService, private matSnackBar: MatSnackBar) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(loginForm: NgForm): void {
    if (loginForm.valid) {
      this.loginService.userAuthentication(loginForm.controls.email.value, loginForm.controls.password.value)
      .subscribe((data: any) => {
        this.loginService.loggedIn.next(true);
        this.loginService.UserName.next(loginForm.controls.email.value);

        localStorage.setItem('userToken', data.access_token);
        localStorage.setItem('userRoles', data.role);
        localStorage.setItem('username', loginForm.controls.email.value);
        let redirect = '';
        if (data.role === '["Admin"]') {
          redirect = this.loginService.redirectUrl ? this.loginService.redirectUrl : '/admin';
        } else if (data.role === '["User"]') {
          redirect = this.loginService.redirectUrl ? this.loginService.redirectUrl : '/user';
        }
        this.router.navigate([redirect]);

      }, (error: HttpErrorResponse) => {
        console.error(error);
        alert(error);
        this.matSnackBar.open('Username or password are invalid.', 'Ok');
      });
    } else {
      this.matSnackBar.open('Username or Password are invalid', 'Ok');
    }
  }

}
