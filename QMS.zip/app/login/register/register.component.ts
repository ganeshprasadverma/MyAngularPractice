import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';
import { Login } from '../../services/login.model';
import { User } from 'src/app/admin/models/user.model';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';

  constructor(private formBuilder: FormBuilder, private matSnackBar: MatSnackBar,
              private loginService: LoginService, private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  resetForm(form?: NgForm) {
    if (form != null) {
      form.reset();
    }
  }

  onSubmit(myForm: NgForm): void {
    if (myForm.controls.password.value !== myForm.controls.confirmPassword.value) {
      this.matSnackBar.open('Password and Confirm Password do not match.');
      return;
    }

    const user = new User();

    user.Email = myForm.controls.email.value;
    user.Password = myForm.controls.password.value;
    user.FirstName = myForm.controls.firstName.value;
    user.LastName = myForm.controls.lastName.value;

    this.loginService.registerUser(user).subscribe((data: any) => {
    if (data.Succeeded) {
      // myForm.reset();
      this.matSnackBar.open('Registration Successull. Please login.', 'OK', {
        duration: 2000
      });
      this.router.navigate(['login']);
    } else {
      this.resetForm(myForm);
    }
    }, (error: any) => {
        console.error(error);
        this.matSnackBar.open('Unable to register User. Internal Server Error.');
        // myForm.reset();
    });
  }

}
