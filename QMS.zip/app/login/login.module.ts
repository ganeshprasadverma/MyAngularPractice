import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { LoginEntryComponent } from './login-entry/login-entry.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { LoginRoutingModule } from './login-routing.module';

@NgModule({
  imports: [
    SharedModule,
    LoginRoutingModule
  ],
  declarations: [LoginEntryComponent, LoginComponent, RegisterComponent]
})
export class LoginModule { }
