import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SecondComponent } from '../components/second/second.component';
import { FirstComponent } from '../components/first/first.component';
import { MyTableComponent } from '../components/my-table/my-table.component';
import { MyModelTableComponent } from '../components/my-model-table/my-model-table.component';
import { LoginLayoutComponent } from '../components/login-layout/login-layout.component';
import { LoginComponent } from '../components/login/login.component';
import { HomeLayoutComponent } from '../components/home-layout/home-layout.component';
import { AboutComponent } from '../components/about/about.component';
import { ContactComponent } from '../components/contact/contact.component';
import { HomeComponent } from '../components/home/home.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  {
    path: 'login', component: LoginLayoutComponent, data: { title: 'Login'},
    children: [
      { path: '', component: LoginComponent }
    ]
  },
  { path: 'main', component: HomeLayoutComponent,
    children: [
      { path: '', redirectTo: 'first', pathMatch: 'full' },
      { path: 'first', component: FirstComponent },
      { path: 'second', component: SecondComponent },
      { path: 'mytable', component: MyTableComponent },
      { path: 'mymodeltable', component: MyModelTableComponent }
    ]
  },
  { path: 'about', component: AboutComponent },
  { path: 'contact', component: ContactComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(appRoutes, { useHash: false }) ], // <-- debugging purposes only
  exports: [ RouterModule ],
  declarations: []
})
export class AppRoutingModule { }
