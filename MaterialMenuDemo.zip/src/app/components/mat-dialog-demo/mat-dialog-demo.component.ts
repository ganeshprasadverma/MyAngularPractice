import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mat-dialog-demo',
  templateUrl: './mat-dialog-demo.component.html',
  styleUrls: ['./mat-dialog-demo.component.css']
})
export class MatDialogDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
