import { Component, OnInit } from '@angular/core';
import { User1 } from '../../model/user1.model';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { User1Service } from '../../services/user1.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  displayedColumns = ['id', 'username', 'salary', 'age'];
  dataSource = new MatTableDataSource<User1>();
  constructor(private router: Router, private userService: User1Service) {
  }

  ngOnInit(): void {
    this.userService.getUsers().subscribe(
      data => {
        this.dataSource.data = data;
      }
    );
  }

}
