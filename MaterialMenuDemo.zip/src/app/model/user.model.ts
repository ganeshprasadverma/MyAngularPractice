export class User {
    position: number;
    firstName: string;
    lastName: string;
    email: string;
}
