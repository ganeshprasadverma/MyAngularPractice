import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../model/employee.model';

@Component({
  selector: 'app-emp-detail',
  templateUrl: './emp-detail.component.html',
  styleUrls: ['./emp-detail.component.css']
})
export class EmpDetailComponent implements OnInit {

  answer = '';
  answerDisplay = '';
  showSpinner = false;

  constructor() { }

  ngOnInit() {
  }

  showAnswer() {
    this.showSpinner = true;

    setTimeout(() => {
      this.answerDisplay = this.answer;
      this.showSpinner = false;
    }, 2000);
  }

}
