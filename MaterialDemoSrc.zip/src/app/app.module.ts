import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';

import {MatButtonModule, MatCheckboxModule, MatToolbarModule,
  MatSidenavModule, MatDialogModule, MatIconModule, MatListModule, MatGridListModule,
  MatCardModule, MatMenuModule, MatTableModule, MatPaginatorModule,
  MatSortModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatInputModule, MatSelectModule } from '@angular/material';

import 'hammerjs';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { MyTableComponent } from './my-table/my-table.component';
import { RouterModule, Routes } from '@angular/router';
import { MyCardComponent } from './my-card/my-card.component';
import { EmpListComponent } from './emp-list/emp-list.component';
import { EmpDetailComponent } from './emp-detail/emp-detail.component';
import { ContactComponent } from './contact/contact.component';
import { ContactListComponent } from './contact-list/contact-list.component';

const appRoutes: Routes = [
  { path: 'menu', component: MenuComponent },
  { path: 'dashboard', component: MyDashboardComponent },
  { path: 'table', component: MyTableComponent },
  { path: 'card', component: MyCardComponent },
  { path: 'empdetail', component: EmpDetailComponent},
  { path: 'contactList', component: ContactListComponent},
  { path: 'empList', component: EmpListComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    MyDashboardComponent,
    MyTableComponent,
    MyCardComponent,
    EmpListComponent,
    EmpDetailComponent,
    ContactComponent,
    ContactListComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCheckboxModule, LayoutModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatDialogModule,
    MatListModule,
    MatGridListModule, MatCardModule, MatMenuModule, MatTableModule,
    MatPaginatorModule, MatSortModule, MatFormFieldModule,
    MatProgressSpinnerModule, MatInputModule, MatSelectModule,
    RouterModule.forRoot(appRoutes)
  ],
  exports: [MatButtonModule, MatToolbarModule, MatProgressSpinnerModule, MatCardModule],
  providers: [],
  entryComponents: [ContactComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
