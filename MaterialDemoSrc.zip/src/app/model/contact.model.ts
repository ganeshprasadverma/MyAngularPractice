export class Contact {
    ID: number;
    FirstName: string;
    LastName: string;
    Contact: string;
    Email: string;
}
