import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ContactService } from '../shared/contact.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  public _contactForm: FormGroup;

  constructor(private _formBuilder: FormBuilder,
    private _dialogRef: MatDialogRef<ContactComponent>, private _conactService: ContactService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this._contactForm = this._formBuilder.group({
      ID: [this.data.ID],
      FirstName: [this.data.FirstName, [Validators.required]],
      LastName: [this.data.LastName, [Validators.required]],
      Contact: [this.data.Contact, [Validators.required]],
      Email: [this.data.Email, [Validators.required]]
    });
  }

  onNoClick(): void {
    this._dialogRef.close();
  }

  onSubmit() {
    if ( isNaN(this.data.ID )) {
      this._conactService.addContact(this._contactForm.value);
      this._dialogRef.close();
    } else {
      this._conactService.editContact(this._contactForm.value);
      this._dialogRef.close();
    }
  }

}
