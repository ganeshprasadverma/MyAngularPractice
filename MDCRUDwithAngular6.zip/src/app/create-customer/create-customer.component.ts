import { Component, OnInit, Inject } from '@angular/core';
import { Customer } from '../model/customer.model';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../services/customer.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.css']
})
export class CreateCustomerComponent implements OnInit {
  panelColor = new FormControl('red');
  title = '';
  isFailedMessage = false;
  isSuccessMessage = false;
  isUpdateMessage = false;
  message = '';
  public globalResponse: any;
  customerForm: FormGroup;
  inputCustomer: Customer;

  constructor(private _fb: FormBuilder, private _customerService: CustomerService,
    private _router: Router, private _dialogRef: MatDialogRef<CreateCustomerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

  }

  titles = [
    { key: 1, value: 'Mr.' },
    { key: 2, value: 'Mrs.' },
    { key: 3, value: 'Miss.' }
  ];

  ngOnInit() {
    console.log(this.data);
    this.title = this.data.Title;
    this.customerForm = this._fb.group({
      Id: [this.data.Id],
      Title: [this.title, Validators.required],
      Name: [this.data.Name, Validators.required],
      Gender: [this.data.Gender, Validators.required],
      Email: [this.data.Email, Validators.required],
      Phone: [this.data.Phone, Validators.required],
      DOB: [this.data.DOB, Validators.required],
      AadharNo: [this.data.AadharNo, Validators.required],
      Address: [this.data.Address, Validators.required],
    });
  }

  onSubmit() {
    if (isNaN(this.data.Id)) {
      this.inputCustomer = this.customerForm.value;
      console.log(this.customerForm.controls['Title'].value);
      this.inputCustomer.Title = this.customerForm.controls['Title'].value;

      // this.inputCustomer.DOB = this.customerForm.controls['DOB'].value.toLocateDateString('en-US');
      this.inputCustomer.DOB = this.customerForm.controls['DOB'].value;
      this.inputCustomer.Id = 0;

      this._customerService.insertCustomer(this.inputCustomer).subscribe(
        (result) => {
          this.globalResponse = result;
        },
        error => {
          this.isFailedMessage = true;
          this.message = 'Customer Insertion Failed';
        },
        () => {
          this.isSuccessMessage = true;
          this.message = 'Cusomter Inserted Successfully';
          this._dialogRef.close();
        });
    } else {
      this.inputCustomer = this.customerForm.value;
      this.inputCustomer.Id = this.data.Id;

      this.inputCustomer.Title = this.customerForm.controls['Title'].value;
      this.inputCustomer.DOB = this.customerForm.controls['DOB'].value;

      this._customerService.updateCustomer(this.data.Id, this.inputCustomer).subscribe(
        data => {
          this.globalResponse = <Customer>data;
        },
        error => {
          this.isFailedMessage = true;
          this.message = 'Cusomter Updation Failed';
        },
        () => {
          this.isUpdateMessage = true;
          this.message = 'Cusomter Updated Successfully';
          this._dialogRef.close();
        });
    }
  }

  onNoClick(): void {
    this._dialogRef.close();
  }
}
