import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Http, Response } from '@angular/http';
import { Observable, of, throwError, pipe } from 'rxjs';
import { map, filter, catchError, mergeMap } from 'rxjs/operators';

import { Customer } from '../model/customer.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  public apiUrl = 'http://localhost:1250/api/Customer';

  constructor(private _httpClient: HttpClient) { }

  // getAllCustomers() {
  //   return this._httpClient.get<Customer[]>(this.apiUrl);
  // }

  // updateCustomer(id: number, customer: Customer) {
  //   console.log(id);
  //   console.log(customer);

  //   return this._httpClient.put<Customer>(this.apiUrl + '/' + id, <Customer>customer).pipe(
  //     map( res => res ),
  //     catchError(this.errorHandler)
  //   );
  // }

  getAllCustomers() {
    return this._httpClient.get(this.apiUrl).pipe(
      map( res => res),
      catchError( this.errorHandler)
    );
  }

  updateCustomer(id: any, customer: any) {
    return this._httpClient.put(this.apiUrl + '/' + id, customer).pipe(
      map( res => res),
      catchError( this.errorHandler)
    );
  }

  insertCustomer(customer: Customer) {
    return this._httpClient.post<Customer>(this.apiUrl, customer)
      .pipe(
        map(res => res),
        catchError(this.errorHandler)
      );
    }

    deleteCustomer(id: number) {
      console.log(this.apiUrl + '/' + id);
      return this._httpClient.delete<Customer>(this.apiUrl + '/' + id);
    }

    errorHandler(error: Response) {
      return throwError(error);
  }
}

