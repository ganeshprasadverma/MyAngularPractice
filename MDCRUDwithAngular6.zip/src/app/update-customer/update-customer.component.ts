import { Component, OnInit } from '@angular/core';
import { MatOptionSelectionChange } from '@angular/material';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../services/customer.service';
import { Customer } from '../model/customer.model';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  title = '';
  isFailedMessage = false;
  isSuccessMessage = false;
  message = '';
  selectedId: number;
  public globalResponse: any;
  customerForm: FormGroup;
  customerForUpdate: Customer;
  AllCustomer: Customer[];
  customerIds = [{}];

  titles = [
    { key: 1, value: 'Mr.' },
    { key: 2, value: 'Mrs.' },
    { key: 3, value: 'Miss.' }
  ];

  constructor(private _customerService: CustomerService,
    private _fb: FormBuilder) {
    this.customerForm = this._fb.group({
      Id: [''],
      Title: ['', Validators.required],
      Name: ['', Validators.required],
      Gender: ['', Validators.required],
      Email: ['', Validators.required],
      Phone: ['', Validators.required],
      DOB: ['', Validators.required],
      AadharNo: ['', Validators.required],
      Address: ['', Validators.required],
    });

    this.getAllCustomers();
  }

  ngOnInit() {

  }

  onSubmit() {
    console.log(this.customerForm.value);
    this.customerForUpdate = this.customerForm.value;
    // this.customerForUpdate.Id = this.customerForm.controls['Id'].value.value;
    // this.customerForUpdate.Title = this.customerForm.controls['Title'].value.value;
    this.customerForUpdate.DOB = this.customerForm.controls['DOB'].value;
    console.log(this.customerForUpdate);
    this._customerService.updateCustomer(this.customerForUpdate.Id, this.customerForUpdate).subscribe((result) => {
      this.globalResponse = result;
    },
      error => {
        this.isFailedMessage = true;
        this.message = 'Customer Update Faileed';
      },
      () => {
        this.isSuccessMessage = true;
        this.message = 'Customer Updated Successfully';
      });
  }

  getAllCustomers() {
    this._customerService.getAllCustomers().subscribe((result) => {
      this.globalResponse = result;
    },
      error => {
        this.isFailedMessage = true;
        this.message = 'Get Customer is failed due to some reason';
      },
      () => {
        this.AllCustomer = this.globalResponse;
        this.AllCustomer.forEach((cust) => {
          const id = { key: cust.Id, value: cust.Id.toString() };
          this.customerIds.push(id);
        });
      });
  }

  fillAllControls(event: MatOptionSelectionChange, Id: any) {
    if (event.isUserInput) {
      this.customerForm.reset();
      const selectedCustomer = this.AllCustomer.filter((cust: Customer) => cust.Id === Id)[0];
      this.title = selectedCustomer.Title;

      this.customerForm.controls['Name'].setValue(selectedCustomer.Name);
      this.customerForm.controls['Gender'].setValue(selectedCustomer.Gender);
      this.customerForm.controls['Phone'].setValue(selectedCustomer.Phone);
      this.customerForm.controls['Email'].setValue(selectedCustomer.Email);
      this.customerForm.controls['AadharNo'].setValue(selectedCustomer.AadharNo);
      this.customerForm.controls['Address'].setValue(selectedCustomer.Address);
      this.customerForm.controls['DOB'].setValue(selectedCustomer.DOB);
    }
  }
}
