import { Component, OnInit } from '@angular/core';
import { CreateCustomerComponent } from '../create-customer/create-customer.component';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { Customer } from '../model/customer.model';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  isPopupOpened = false;
  CustomerList: any;
  constructor(private _matDialog: MatDialog, private _customerService: CustomerService,
    private _router: Router) { }

  ngOnInit() {
    this.getCustomerList();
  }

  getCustomerList() {
    return this._customerService.getAllCustomers().subscribe( data => {
      this.CustomerList = data;
    });
  }

  addCustomer() {
    this.isPopupOpened = true;
    const dialogRef = this._matDialog.open(CreateCustomerComponent, {
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    });
  }

  editCustomer(id: number) {
    this.isPopupOpened = true;
    const customer = this.CustomerList.find(c => c.Id === id);
    const dialogRef = this._matDialog.open(CreateCustomerComponent, {
      data: customer
    });
  }

  deleteCustomer(id: number) {
    if ( confirm('Are you sure you want to delete this ?')) {
      this._customerService.deleteCustomer(id).subscribe( data => {
        if (data.Id > 0) {
          this.getCustomerList();
      }
      });
    }
    return;
  }
}
