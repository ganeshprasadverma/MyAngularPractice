import { Routes } from '@angular/router';
import { MenuComponent } from './menu/menu.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MytableComponent } from './mytable/mytable.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';

export const appRoutes: Routes = [
{ path: 'menu', component: MenuComponent },
{ path: 'dashboard', component: DashboardComponent },
{ path: 'table', component: MytableComponent },
{ path: 'createcustomer', component: CreateCustomerComponent},
{ path: 'updatecustomer', component: UpdateCustomerComponent},
{ path: 'customerlist', component: CustomerListComponent},
{ path: '', redirectTo: '/dashboard', pathMatch: 'full' }
];
