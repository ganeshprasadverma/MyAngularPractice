export class Customer {
    Id: number;
    Title: string;
    Name: string;
    Gender: string;
    Email: string;
    Phone: string;
    DOB: Date;
    AadharNo: string;
    Address: string;
}
