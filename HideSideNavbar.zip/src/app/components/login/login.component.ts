import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { AuthService } from '../../services/auth.service';
import { TokenStorageService } from '../../services/TokenStorage.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email: string;
  password: string;
  loginForm: FormGroup;
  submitted = false;
  invalidLogin = false;

  constructor(private _router: Router, public _matDialog: MatDialog, private _authService: AuthService,
    private _tokenService: TokenStorageService, private _formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.loginForm = this._formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    if (this.loginForm.controls.email.value === 'ganesh.verma38@gmail.com'
        && this.loginForm.controls.password.value === 'ganeshverma') {
        this._router.navigate(['main']);
    } else {
      this.invalidLogin = true;
    }
    // this._authService.attemptAuth(this.email, this.password).subscribe(
    //   data => {
    //     this._tokenService.saveToken(data.token);
    //     this._router.navigate(['user']);
    //   });
  }

}
