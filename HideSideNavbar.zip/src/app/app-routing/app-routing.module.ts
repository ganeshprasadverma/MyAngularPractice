import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SecondComponent } from '../components/second/second.component';
import { FirstComponent } from '../components/first/first.component';
import { MyTableComponent } from '../components/my-table/my-table.component';
import { MyModelTableComponent } from '../components/my-model-table/my-model-table.component';
import { LoginLayoutComponent } from '../components/login-layout/login-layout.component';
import { LoginComponent } from '../components/login/login.component';
import { HomeLayoutComponent } from '../components/home-layout/home-layout.component';

// const appRoutes: Routes = [
//   { path: '', component: FirstComponent, data: { title: 'First Component' } },
//   { path: 'first', component: FirstComponent, data: { title: 'First Component' } },
//   { path: 'second', component: SecondComponent, data: { title: 'Second Component' } },
//   { path: 'mytable', component: MyTableComponent, data: { title: 'Table Component' } },
//   { path: 'mymodeltable', component: MyModelTableComponent, data: { title: 'Model Table Component' } }
// ];

const appRoutes: Routes = [
  { path: '', redirectTo: 'login', data: { title: 'First Component' }, pathMatch: 'full' },
  {
    path: 'login', component: LoginLayoutComponent, data: {title: 'First Component'},
    children: [
      { path: '', component: LoginComponent }
    ]
  },
  { path: 'main', component: HomeLayoutComponent,
    children: [
      { path: '', redirectTo: 'first', pathMatch: 'full' },
      { path: 'first', component: FirstComponent },
      { path: 'second', component: SecondComponent },
      { path: 'mytable', component: MyTableComponent },
      { path: 'mymodeltable', component: MyModelTableComponent }
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forRoot(appRoutes, { useHash: false }) ], // <-- debugging purposes only
  exports: [ RouterModule ],
  declarations: []
})
export class AppRoutingModule { }
