export class User1 {
  id: number;
  username: string;
  salary: number;
  age: number;
}
