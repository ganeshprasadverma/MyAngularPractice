import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatNativeDateModule, MatIconModule, MatSidenavModule,
  MatListModule, MatToolbarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule, MatCardModule, MatDialogModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule, MatCardModule, MatDialogModule,
    MatButtonModule, MatNativeDateModule, MatIconModule,
    MatSidenavModule, MatListModule, MatToolbarModule,
    MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule
  ],
  exports: [
    MatButtonModule, MatNativeDateModule, MatIconModule, MatCardModule,
    MatSidenavModule, MatListModule, MatToolbarModule, MatDialogModule,
    MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule
  ],
  declarations: []
})
export class AppMaterialModule { }
