import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { User } from '../model/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  public getUsers(): Observable<any> {
    const fakeUsers: User[] = [
      { position: 1, firstName: 'ganesh', lastName: 'verma', email: 'ganesh.verma38@gmail.com' },
      { position: 2, firstName: 'Tom', lastName: 'Jac', email: 'Tom@gmail.com' },
      { position: 3, firstName: 'Hary', lastName: 'Pan', email: 'hary@gmail.com' },
      { position: 4, firstName: 'praks', lastName: 'pb', email: 'praks@gmail.com' },
    ];
    return of(fakeUsers);
  }
}
